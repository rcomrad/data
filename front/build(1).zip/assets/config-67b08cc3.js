const s="https://kusmirror.ru/api",r=20,t="https://kusmirror.ru";export{s as A,r as M,t as a};
