a1 = list(input().split())
f = 0
a2 = 0

for i in range(5):
    a2 += int(a1[i])

for i in range(5):
    if int(a1[i]) > a2 - int(a1[i]) or int(a1[i]) < 0:
        f = 1

if f == 1:
    print('NO')
else:
    print('YES')