inp = input()
alph = "abcdefghijklmnopqrstuvwxyz"
pockets = []
for i in range(len(alph)):
    if inp == alph[i]:
        temp = [alph[i], 1]
    else:
        temp = [alph[i], 0]
    pockets.append(temp)
tempInp = input()
while tempInp != "?":
    tempPockets = tempInp.split(" ")
    a = tempPockets[0]
    b = tempPockets[1]
    for i in range(len(pockets)):
        if a == pockets[i][0]:
            indA = i
        if b == pockets[i][0]:
            indB = i
    t = pockets[indA][1]
    pockets[indA][1] = pockets[indB][1]
    pockets[indB][1] = t
    tempInp = input()
for i in range(len(pockets)):
    if pockets[i][1] == 1:
        print(pockets[i][0])
        break


