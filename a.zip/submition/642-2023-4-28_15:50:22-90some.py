ans = input()
key = ans
while True:
    if ans[0] == '?':
        break
    if key in ans:
        i = ans.index(key)
        key = ans[i - 1]
    ans = list(map(str, input().split()))

print(key)