def frequency_sort(items):
    return sorted(items, key=lambda part: (-items.count(part), part))
s=input()
a=set()
s1="".join(c for c in s if  c.isdecimal())
s1=frequency_sort(s1)
s1=set(s1)
print(' '.join(s1))

        
