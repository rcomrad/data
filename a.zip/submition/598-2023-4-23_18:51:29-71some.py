a = input()
what = 0
if a == 'a':
    what = 'a'
if a == 'b':
    what = 'b'
if a == 'c':
    what = 'c'
c=' '
while (c[0]!='?'):
    c = input().split()
    if c[0] == '?':
        break
    if (what == 'a' and c[1] == 'b') or (c[0] == 'a' and what == 'b'):
        if what == 'a':
            what = 'b'
        elif what == 'b':
            what = 'a'
    elif (what == 'a' and c[1] == 'c') or (c[0] == 'a' and what == 'c'):
        if what == 'a':
            what = 'c'
        elif what == 'c':
            what = 'a'
    elif (what == 'b' and c[1] == 'c') or (c[0] == 'b' and what == 'c'):
        if what == 'b':
            what = 'c'
        elif what == 'c':
            what = 'b'
    elif (what == 'b' and c[1] == 'a') or (c[0] == 'b' and what == 'a'):
        if what == 'b':
            what = 'a'
        elif what == 'a':
            what = 'b'
    elif (what == 'c' and c[1] == 'a') or (c[0] == 'c' and what == 'a'):
        if what == 'c':
            what = 'a'
        elif what == 'a':
            what = 'c'
    elif (what == 'c' and c[1] == 'b') or (c[0] == 'c' and what == 'b'):
        if what == 'c':
            what = 'b'
        elif what == 'b':
            what = 'c'
        
print(what)
    
    