s=input()
count=s.count('*')
length=0
for i in range(len(s)-1):
    count+=input().count('*')
item=str(round((count/len(s)-1),4))
print(item+(4-(len(item)-1-item.find('.')))*'0' )
