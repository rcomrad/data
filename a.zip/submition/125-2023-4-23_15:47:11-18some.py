a,b,c,d,e = map(int,input().split())
sum = a + b + c + d + e
if 2 * max(a,b,c,d,e) <= sum:
    print('YES')
else:
    print('NO')