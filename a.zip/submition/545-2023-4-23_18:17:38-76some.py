a = input()
b = a.split()
print(b)