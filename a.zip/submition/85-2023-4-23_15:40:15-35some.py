a = input()
zvezd = a.count("*")
print(zvezd / 4 - 1)
        
