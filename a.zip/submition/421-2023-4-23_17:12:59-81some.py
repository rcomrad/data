a=str(input())
if a.count("2")>a.count("1"):
    print("2","1")
elif a.count("1")>a.count("2"):
    print("1","2")
else:
    print("2","1")