def unc(mas1, s1, c1, s2, c2):
    neighbors = lambda x, y, mas1: [(x2, y2) for x2 in range(x - 1, x + 2)
                                    for y2 in range(y - 1, y + 2)
                                    if (-1 < x <= n - 1 and
                                        -1 < y <= m - 1 and
                                        abs(x - x2) != abs(y - y2) and
                                        (x != x2 or y != y2) and
                                        (0 <= x2 <= n - 1) and
                                        (0 <= y2 <= m - 1) and
                                        mas1[x2][y2] != '*')]
    mas = [[-1] * n for i in range(n)]
    mas[s1 ][c1 ] = 0
    for i in range(n*m):
        for i in range(n):
            for j in range(n):
                if mas[i][j] != 0:
                    for kk in neighbors(i, j, mas1):
                        if mas[kk[0]][kk[1]] == -1:
                            mas[kk[0]][kk[1]] = mas[i][j] + 1
        if mas[s2][c2] != -1:
            return True
    if mas[s2 ][c2] != -1:
        return True
    return False
n, m =map(int, input().split())
mas=[]
s1, s2, f1, f2, c=0, 0, 0, 0, []
for i in range(n):
    mas.append([])
    s=list(input())
    for j in range(m):
        if s[j]=='C':
            c.append([i, j])
        if s[j]=='F':
            s[j]='*'
        if s[j]=='S':
            s1, s2=i, j
        mas[-1].append(s[j])
sir=0
for i in c:
    if unc(mas, s1, s2, i[0], i[1]):
        sir+=1
print(sir)