#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;

int main()
{
    std::unordered_map<char, char> m;
    for (char c = 'a'; c <= 'z'; ++c)
    {
        m[c] = 0;
    }

    std::string s;
    std::getline(cin, s);
    m[s[0]]++;
    while (true)
    {

        std::getline(cin, s);

        if (s == "?") break;
        std::swap(m[s[0]], m[s[2]]);
    }

    for (auto& i : m)
    {
        if (i.second == 1)
        {
            cout << i.first;
        }
    }
	
	return 0;
}