n = input()
a, b, c = 0, 0, 0
tempo = 0
if n == "a":
    a = 1
elif n == "b":
    b = 1
else:
    c = 1
while True:
    ls = list(input())
    if ls == ["?"]:
        break
    else:
        if ls[0] == "a":
            if ls[2] == "b":
                tempo = a
                a = b
                b = tempo
            else:
                tempo = a
                a = c
                c = tempo
        elif ls[0] == "b":
            if ls[2] == "a":
                tempo = b
                b = a
                a = tempo
            else:
                tempo = b
                b = c
                c = tempo
        else:
            if ls[2] == "a":
                tempo = c
                c = a
                a = tempo
            else:
                tempo = c
                c = b
                b = tempo
if a == 1:
    print("a")
elif b == 1:
    print("b")
else:
    print("c")