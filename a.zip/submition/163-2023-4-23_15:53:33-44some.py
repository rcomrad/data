a = input()
b = input()
b = ''.join(b)
if a in b:
    if b[0] == a:
        a = b[1]
    else:
        a = b[0]
while b != '?':
    b = input()
    b = ''.join(b)
    if a in b:
        if b[0] == a:
            a = b[1]
        else:
            a = b[0]
print(a)