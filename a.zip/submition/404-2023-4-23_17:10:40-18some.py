sas = str(input())
while True:
    ded = list(map(str,input().split()))
    if ['?'] == ded:
        print(str(sas))
        break
    elif ded[0] != ded[1]:
        if ded[0] == sas:
            sas = ded[1]