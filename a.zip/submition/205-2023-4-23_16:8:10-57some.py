f =[]
while True:
    try:
        n = input()
    except EOFError:
        break
    f.append(n.count('*'))
print(sum(f)/len(f)-1)