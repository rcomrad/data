sas = [list(map(str, input()))]
s = sas[0].count('*')
for i in range(len(sas[0]) - 1):
    s += list(map(str, input())).count('*')
b = round(((s / len(sas[0])) -1),4)
b = f"{b:.{4}f}"
print(b)