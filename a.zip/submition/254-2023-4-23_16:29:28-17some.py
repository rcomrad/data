n, m = map(int, input().split())
maze = [input() for _ in range(n)]

# Находим координаты входа и выхода
for i in range(n):
    for j in range(m):
        if maze[i][j] == 'S':
            start = (i, j)
        elif maze[i][j] == 'F':
            end = (i, j)

# Функция для поиска пути в лабиринте
def bfs(maze, start, end):
    visited = set()
    queue = [start]
    dx = [-1, 0, 1, 0] # Смещение по вертикали
    dy = [0, 1, 0, -1] # Смещение по горизонтали
    cheese = 0 # Счетчик сыра

    while queue:
        x, y = queue.pop(0)
        if (x, y) == end:
            return cheese
        for i in range(4):
            nx, ny = x + dx[i], y + dy[i]
            if 0 <= nx < n and 0 <= ny < m and (nx, ny) not in visited and maze[nx][ny] != '*':
                visited.add((nx, ny))
                queue.append((nx, ny))
                if maze[nx][ny] == 'C':
                    cheese += 1
    return cheese

print(bfs(maze, start, end))
