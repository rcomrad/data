s = input()

digits = [0] * 10
for c in s:
    if c.isdigit():
        digits[int(c)] += 1

sorted_digits = sorted(range(10), key=lambda x: (-digits[x], x))
for d in sorted_digits:
    if digits[d] > 0:
        print(d, end=' ')
