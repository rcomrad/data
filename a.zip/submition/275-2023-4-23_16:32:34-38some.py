s = list(map(int, input().split()))
m = sum(s)
for i in s:
    if i > m - i:
        print('NO')
        exit()
else:
    print('YES')