kol=0
s=input()
n=len(s)
for i in range(n):
    l=0
    for j in s:
        kol+=int(j=='*')
        l+=1
    if i!=n-1:
        s=input()
print(kol/l-1)