sas = str(input())
d = {str(i) for i in range(10)}
ans = [[i,0] for i in range(10)]
ded = []
for i in sas:
    if i in d:
        i = int(i)
        ans[i][1] += 1
ans.sort(reverse=True, key=lambda ans: ans[1])
for i in range(len(ans)):
    if ans[i][1] == 0:
        continue
    if i > 0:
        if ans[i-1][1] == ans[i][0]:
            ded[-1].append(ans[i][0])
        else:
            ded.append([ans[i][0]])
    else:
        ded.append([ans[i][0]])
for i in ded:
    for u in i[::-1]:
        print(u, end=" ")
print(sep=' ')