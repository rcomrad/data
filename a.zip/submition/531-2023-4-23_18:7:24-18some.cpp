#include <bits/stdc++.h>

using namespace std;

int main()
{
    int a,b,c,d,e,sum;
    cin >> a >> b >> c >> d >> e;
    sum = a + b + c + d + e;
    if (max(max(max(a,b),max(c,d)),e) * 2 <= sum && min(min(min(a,b),min(c,d)),e) >= 0){
        cout << "YES" << endl;
    } else {
        cout << "NO" << endl;
    }
}
