a = input()
b = input()
ft = True
if b == '?':
    ft = False
else:
    b = b.split()
if a == b[0]:
    a = b[1]
elif a == b[1]:
    a = b[0]
else:
    a = a
print(a)
while ft:
    b = input()
    if b == '?':
        ft = False
        break
    else:
        b = b.split()
    if a == b[0]:
        a = b[1]
    elif a == b[1]:
        a = b[0]
    else:
        a = a
    print(a)
print(a)