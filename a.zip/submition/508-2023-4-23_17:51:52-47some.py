a, b, c, d, e = map(int, input().split())
x = max(a, b, c, d, e)
if x > (a + b + c + d + e - x):
    print('NO')
else:
    print('YES')
