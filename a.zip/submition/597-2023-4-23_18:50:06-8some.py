mas=list(map(int, input().split()))
ma=max(mas)
mas.remove(ma)
if ma==0:
    print('NO')
else:
    if sum(mas)>=ma:
        print('YES')
    else:
        print('NO')