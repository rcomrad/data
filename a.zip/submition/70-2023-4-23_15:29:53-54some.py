w = input()
a = {}
d = list(input().split())

while d[0] != '?':
    if d[0] == w:
        w = d[1]
    elif d[1] == w:
        w = d[0]
    
    d = list(input().split())

print(w)