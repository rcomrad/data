a,b = map(int,input().split())
c = []
for i in range(a):
    c.append(input())
k = 0
for i in c:
    if 'C' in i:
        k+=1
print(k)