sas = str(input())
while True:
    ded = list(map(str,input().split()))
    if '?' in ded:
        print(sas)
        break
    elif ded[0] != ded[1]:
        if ded[0] == sas:
            sas = str(ded[0])
        elif ded[1] == sas:
            sas = str(ded[0])