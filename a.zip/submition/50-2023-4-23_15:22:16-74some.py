n = [int(i) for i in input().split()]
flag = 1
for i in n:
    if i > sum(n) - i:
        flag = 0
if flag:
    print('YES')
else:
    print('NO')
