f = list(map(int, input().split()))
flag = True
for i in range(5):
    t = f.copy()
    t.pop(i)
    if f[i]>sum(t):
        flag = False
if flag:
    print('YES')
else:
    print('NO')
