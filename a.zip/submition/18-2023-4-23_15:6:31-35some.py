a, b, c, d, e = map(int, input().split())
maxx = max(a, b, c, d, e)
if (a + b + c + d + e) / maxx >= 2:
    print("YES")
else:
    print("NO")
