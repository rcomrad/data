#                  *1*

s = input()
s1 = []
for i in s:
    if i in '1234567890':
        s1.append(int(i))
s = s1.copy()
# теперь s - изначальная строка только из чисел

#                  *2*
s_s = list(set(s))
a = dict()
for i in s_s:
    a[i] = s.count(i)
r = a.values()
r = list(set(r))
r.sort(reverse = True)
k = a.keys()
for i in r:
    t = []
    for j in k:
        if a[j] == i:
            t.append(j)
    t.sort(reverse = True)
    print(*t, end = ' ')