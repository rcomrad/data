a = map(int, input().split(" "))

if min(a) < 0:
    print("NO")
    quit()

for x in a:
    if sum(a) - x >= x:
        continue

    else:
        print("NO")
        quit()

print("YES")