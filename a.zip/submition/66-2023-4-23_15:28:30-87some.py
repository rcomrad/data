s = input()
cnt = {}
for i in s: cnt[i] = 0
for i in s:
	if ord('0') <= ord(i) <= ord('9'):
		cnt[i] += 1
cnt2 = []
for i in cnt:
	cnt2.append((cnt[i], i))
cnt2.sort()
ans = []
for i in cnt2:
	if i[0] == cnt2[-1][0]: ans.append(i[1])
ans.sort(reverse=True)
print(*ans)
