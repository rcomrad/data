#include <bits/stdc++.h>

using namespace std;

int main()
{
    string s;
    vector<string> sas = {"a","a"};
    cin >> s;
    while (true){
        cin >> sas[0];
        if (sas[0] != "?"){
            cin >> sas[1];
            if (sas[0] == s){
                s = sas[1];
            } else if (sas[1] == s){
                s = sas[0];
            }
        } else {
            cout << s << endl;
            return 0;
        }
    }
}
