n, m = map(int, input().split())
a = []
for i in range(n):
    x = list(input())
    a.append(x)
b = a.copy()
for i in b:
    if 'S' in i:
        i[i.index('S')] = 1
flag = True
count = 0
while flag:
    flag = False
    for i in range(n):
        for j in range(m):
            if b[i][j] == 1:
                try:
                    if b[i - 1][j] == ' ':
                        b[i - 1][j] = 1
                        flag = True
                    if b[i + 1][j] == ' ':
                        b[i + 1][j] = 1
                        flag = True
                    if b[i][j - 1] == ' ':
                        b[i][j - 1] = 1
                        flag = True
                    if b[i][j + 1] == ' ':
                        b[i][j + 1] = 1
                        flag = True

                    if b[i - 1][j] == 'C':
                        b[i - 1][j] = 1
                        count += 1
                        flag = True
                    if b[i + 1][j] == 'C':
                        b[i + 1][j] = 1
                        count += 1
                        flag = True
                    if b[i][j - 1] == 'C':
                        b[i][j - 1] = 1
                        count += 1
                        flag = True
                    if b[i][j + 1] == 'C':
                        b[i][j + 1] = 1
                        count += 1
                        flag = True
                except IndexError:
                    continue
for i in range(n):
    for j in range(m):
        if a[i][j] == 'F':
            coords = [i, j]
i, j = coords
if (i - 1 >= 0 and b[i - 1][j] == 1)\
        or (i + 1 < n and b[i + 1][j] == 1)\
        or (j - 1 >= 0 and b[i][j - 1] == 1)\
        or (j + 1 < m and b[i][j + 1] == 1):
    print(count)
else:
    print(0)
