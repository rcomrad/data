def issum5(a,b,c,d,e):
    if a <= b+c+d+e:
        return True
    return False
a,b,c,d,e = map(int,input().split())
if issum5(a, b, c, d, e) and issum5(b, a, c, d, e) and issum5(c, b, a, d, e) and issum5(d, b, c, a, e):
    print('YES')
else:
    print('NO')