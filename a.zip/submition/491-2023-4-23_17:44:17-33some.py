st = input()
v = 0
d = [0 for i in range(10)]
for elem in st:
    if str.isdigit(elem):
        d[int(elem)] += 1
pairs = [(i, d[i]) for i in range(len(d))]
sorted_pairs = sorted(pairs, reverse=True, key=lambda x: (x[1], x[0]))
filtered_pairs = filter(lambda x: x[1]>0, sorted_pairs)
print(" ".join(map(str, [elem[0] for elem in filtered_pairs])))
