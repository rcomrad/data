﻿#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
	int sum = 0;
	vector <int> arr(5);
	for (int i = 0; i < 5; ++i) {
		cin >> arr[i];
		sum += arr[i];
	}
	
	for (auto i : arr) {
		if (i < 0 || i > sum - i) {
			cout << "NO";
			exit(0);
		}
	}

	cout << "YES";
	return 0;
}