a, b, c, d, e = map(int, input().split())
sides = [a, b, c, d, e]
sides.sort()
if sides[0] + sides[1] + sides [2] + sides [3] >= sides[4] and sides[4] + sides[1] + sides [2] + sides [3] >= sides[0] and sides[4] + sides[0] + sides [1] + sides [3] >= sides[2] and sides[4] + sides[0] + sides [2] + sides [3] >= sides[1] and sides[4] + sides[0] + sides [2] + sides [1] >= sides[3]:
    
    print("YES")
else:
    print("NO")
