s = list(map(int, input().split()))
s.sort()
if s[0] + s[1] + s[2] + s[3] > s[4] or s[0] + s[1] + s[2] + s[4] > s[3] or s[0] + s[1] + s[3] + s[4] > s[2] or s[0] + s[2] + s[3] + s[4] > s[1] or s[1] + s[2] + s[3] + s[4] > s[0]:
    print("YES")
else:
    print("NO")