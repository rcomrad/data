from collections import Counter

def key(a):
    return [dc_counter[a], int(a)]

string = input('')

len_string = len(string)

dc_counter = Counter(string)

ls = list(map(str, range(10)))

ls.sort(reverse = True, key = key)

for i in range(10):
    if dc_counter[ls[i]] == 0:
        break
    print(ls[i], end = ' ')

print()
