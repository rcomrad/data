import sys

c = 0
n = 0
for i in sys.stdin:
    for j in i:
        if j == '*':
            n += 1
    c += 1
print(n / c - 1)
