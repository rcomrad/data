sas = str(input())
while True:
    ded = list(map(str,input().split()))
    if '?' in ded:
        print(sas)
        break
    else:
        if ded[0] == sas:
            sas = ded[1]
        elif ded[1] == sas:
            sas = ded[0]