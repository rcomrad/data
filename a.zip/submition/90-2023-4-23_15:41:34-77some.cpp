message = input()
freq = {}
for char in message:
    if char.isdigit():
        if char not in freq:
            freq[char] = 1
        else:
            freq[char] += 1
sorted_freq = sorted(freq, key=freq.get, reverse=True)
print(" ".join(sorted_freq))
    
