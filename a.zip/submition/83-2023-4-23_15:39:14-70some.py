sign = input()
prize = 1
dict1 = {sign: 1}
a = input()
while a != '?':
    s1, s2 = a.split()
    if s1 not in dict1.keys():
        dict1[s1] = 0
    if s2 not in dict1.keys():
        dict1[s2] = 0
    dict1[s1], dict1[s2] = dict1[s2], dict1[s1]
    a = input()
s = [(i, dict1[i]) for i in dict1.keys()]
d = [i[1] for i in s].index(1)
print(s[d][0])







