gde = input()
a = input()
while a != '?':
    s, f = map(str, a.split())
    if s == gde:
        gde = f
    elif f == gde:
        gde = s
    a = input()
print(gde)
