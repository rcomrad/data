message = input().strip()
digits = [int(d) for d in message if d.isdigit()]
freq = {d: digits.count(d) for d in set(digits)}
sorted_digits = sorted(freq.keys(), key=lambda x: (-freq[x], -x))
print(" ".join(str(d) for d in sorted_digits))
