from sys import stdin


width = 0
sum = 0
for line in stdin:
    if not width:
        width = len(line) - 1
    sum += line.count("*")
print(round(sum / width - 1, 4))