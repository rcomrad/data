string = input() # ввод строки-сообщения
 
digits = {} # словарь для подсчёта цифр
 
# проходимся по символам строки и считаем количество вхождений каждой цифры
for char in string:
    if char.isdigit():
        if char in digits:
            digits[char] += 1
        else:
            digits[char] = 1
 
# сортируем словарь по значению (частоте встречаемости цифры)
sorted_digits = sorted(digits.items(), key=lambda item: item[1], reverse=True)
 
# выводим цифры в порядке убывания частоты их встречания
for digit in sorted_digits:
    print(digit[0], end=' ')
