a,b,c,d,e=map(int, input().split())
if a <= b+d+c+e and b <= a+d+c+e and d <= b+a+c+e and c <= b+d+a+e and e <= b+d+c+a:
    print("YES")
else:
    print("NO")