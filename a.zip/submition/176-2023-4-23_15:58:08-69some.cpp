a=input()
b=list(input().split())
while b[0]!="?":
    if a in b:
        if a==b[0]:
            a=b[1]
        else:
            a=b[0]
    b=list(input().split())
print(a)
