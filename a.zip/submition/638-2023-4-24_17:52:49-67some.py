swap = " "
pocket = input()
while swap != "?":
    swap = input()
    if swap == "?":
        break
    a, b = swap.split()
    if a == pocket:
        pocket = b
        continue
    elif b == pocket:
        pocket = a
        continue
print(pocket)
