import operator
a = input()

ls = []
for i in range(10):
	ls.append((i, a.count(str(i))))
ls.sort(key=lambda x: x[1], reverse=True)

ls2 = []
for i in ls:
	if i[1] == 0:
		break
	ls2.append(i)
ls2.sort(key= operator.itemgetter(1, 0), reverse=True)
print(*map(lambda x : x[0], ls2))