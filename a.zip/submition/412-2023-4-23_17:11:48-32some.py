from collections import deque

n, m = map(int, input().split())
grid = [input() for _ in range(n)]
start = end = None
for i in range(n):
    for j in range(m):
        if grid[i][j] == 'S':
            start = (i, j)
        elif grid[i][j] == 'F':
            end = (i, j)


queue = deque([start])
visited = set([start])
cheese_count = 0
while queue:
    x, y = queue.popleft()
    if (x, y) == end:
        break
    for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        nx, ny = x + dx, y + dy
        if 0 <= nx < n and 0 <= ny < m and grid[nx][ny] != '*' and (nx, ny) not in visited:
            visited.add((nx, ny))
            queue.append((nx, ny))
            if grid[nx][ny] == 'C':
                cheese_count += 1

print(cheese_count)
