import random
n, m = map(int,input().split())
n, m = map(input())
a = random.randint(1,2)
f = n + m
for i in range(f):
    if a == 1:
        n, m.append('*' and 'S' and 'C' and 'F')
    else:
        break


print(n, m)