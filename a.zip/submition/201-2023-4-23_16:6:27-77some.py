a = input()
def count_digits(msg):
    digit_counts = [0] * 10
    
    for char in msg:
        if char.isdigit():
            digit_counts[int(char)] += 1
    
    digits_sorted = sorted(range(10), key=lambda i: digit_counts[i], reverse=True)
    digits_output = " ".join(str(d) for d in digits_sorted if digit_counts[d] > 0)
    
    return digits_output
print(count_digits(a))
