n, m = map(int, input().split())

maze = []
for i in range(n):
    maze.append(list(input()))

def find_path(maze, visited, i, j, found_exit):
    if i < 0 or j < 0 or i >= len(maze) or j >= len(maze[0]):
        return False
    if visited[i][j]:
        return False
    if maze[i][j] == '*':
        return False
    if maze[i][j] == 'F':
        found_exit = True
        return True
    if maze[i][j] == 'C':
        maze[i][j] = ' '
        found_cheese = find_path(maze, visited, i+1, j, found_exit) or \
                       find_path(maze, visited, i-1, j, found_exit) or \
                       find_path(maze, visited, i, j+1, found_exit) or \
                       find_path(maze, visited, i, j-1, found_exit)
        maze[i][j] = 'C'
        return found_cheese
    visited[i][j] = True
    path_found = find_path(maze, visited, i+1, j, found_exit) or \
                 find_path(maze, visited, i-1, j, found_exit) or \
                 find_path(maze, visited, i, j+1, found_exit) or \
                 find_path(maze, visited, i, j-1, found_exit)
    visited[i][j] = False
    return path_found

cheeses_collected = 0
while True:
    visited = [[False] * m for i in range(n)]
    for i in range(n):
        for j in range(m):
            if maze[i][j] == "S":
                break
    if not find_path(maze, visited, i, j, False):
        break
    cheeses_collected += 1

print(cheeses_collected)
