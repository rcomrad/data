sizes = list(map(int, input().split()))
spaces = {}
cheese = []
start = ()
for y in range(sizes[0]):
    for x, symb in enumerate(input()):
        if symb != "*":
            spaces[(x, y)] = 0
            if symb == "C":
                cheese.append((x, y))
            elif symb == "S":
                start = (x, y)


def find_ways(spaces, points):
    now_points = points.copy()
    points.clear()
    for point in now_points:
        spaces[point] = 1
        if spaces.get((point[0] + 1, point[1]), 1) != 1:
            points.append((point[0] + 1, point[1]))
        if spaces.get((point[0] - 1, point[1]), 1) != 1:
            points.append((point[0] - 1, point[1]))
        if spaces.get((point[0], point[1] + 1), 1) != 1:
            points.append((point[0], point[1] + 1))
        if spaces.get((point[0], point[1] - 1), 1) != 1:
            points.append((point[0], point[1] - 1))
    if points:
        find_ways(spaces, points)
    return spaces


answer = find_ways(spaces, [start])
print(len([1 for one in cheese if answer.get(one, 0) == 1]))
