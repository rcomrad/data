'''
def calculate_mean_count(arr):
    sum_count = 0
    num_count = 0    
    for row in arr:
        count = 0
        for cell in row:
            if cell == "*":
                count += 1
        if count > 0:
            sum_count += count
            num_count += 1
    mean_count = sum_count / num_count - 1
    return round(mean_count, 4)
b=[]
s=list(input())
while s!='':
    b.append(s)
    s=input()
ld=calculate_mean_count(b)
a=str(ld)
while len(a)<8:
    a+='0'
print(a)
'''
s=input()
summ=0
su=0
c=0
for i in range(1000000000000000000):
    if s=='':
        break
    else:
        su=s.count('*')
    summ+=su
    c+=1
    s=input()
a=str((summ/c)-1)
while len(a)<8:
    a+='0'
print(a)
