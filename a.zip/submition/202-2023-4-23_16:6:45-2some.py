a = [int(x) for x in input().split()]
m = max(a)
n = min(a)
if m < sum(a) and n > 0:
    print("YES")
else:
    print("NO")