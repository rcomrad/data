a = list(map(int, input().split()))
s = sum(a)
ans = 'YES'
for i in a:
    if i > s - i or i < 0:
        ans = 'NO'        
print(ans)
