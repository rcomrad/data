
#include <cstdio>
 
t main()
{
	printf("Hello world");
}
