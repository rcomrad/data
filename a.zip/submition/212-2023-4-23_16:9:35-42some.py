n1, n2, n3, n4, n5 = map(int, input().split())
num1 = ""
num2 = ""
num3 = ""
num4 = ""
num5 = ""
if n1 <= n2+n3+n4+n5:
    num1 = "Y"
else:
    num1 = "N"
if n2 <= n1+n3+n4+n5:
    num2 = "Y"
else:
    num2 = "N"
if n3 <= n2+n1+n4+n5:
    num3= "Y"
else:
    num3 = "N"
if n4 <= n2+n3+n1+n5:
    num4 = "Y"
else:
    num4 = "N"
if n5 <= n2+n3+n4+n1:
    num5 = "Y"
else:
    num5 = "N"

if num1+num2+num3+num4+num5 == "YYYYY":
    print("YES")
else:
    print("NO")
