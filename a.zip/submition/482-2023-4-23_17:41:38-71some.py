a, b, c, d, e = map(int, input().split())
i = 0
if (a <= (b+c+d+e)):
    i+=1
if (b <= (a+c+d+e)):
    i+=1
if (c <= (b+a+d+e)):
    i+=1
if (d <= (b+c+a+e)):
    i+=1
if (e <= (b+c+d+a)):
    i+=1
if i == 5:
    print("YES")
else:
    print ("NO")