a = input()
b = input()
ft = True
if b == '?':
    ft = False
else:
    b = b.split()
if a == b[0]:
    a = b[1]
else:
    a = b[0]
while ft:
    b = input()
    if b == '?':
        ft = False
        break
    else:
        b = b.split()
    if a == b[0]:
        a = b[1]
    else:
        a = b[0]
print(a)