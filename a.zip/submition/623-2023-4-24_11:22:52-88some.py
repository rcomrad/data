now = input()
a = list(map(str, input().split()))
while a != ['?']:
    if now in a:
        now = a[1 - a.index(now)]
    a = list(map(str, input().split()))
print(now)
