'''
  * 
  * 
 ***
****
'''
from sys import stdin
count=0
length=0
for item in stdin:
    count+=item.count('*')
    length+=1
print(str(round((count/length-1),4))+'0000')
