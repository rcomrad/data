m = input()
a = input().split()
if len(a) == 2 or a[0] == '?':
    while a[0] != '?':
        if m == a[0]:
            m = a[1]
        if m == a[1]:
            m = a[0]
        a = input().split()
    print(m)
