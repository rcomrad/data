n1 = input()
fl = True
cur = n1
while fl:
    s = input()
    if s == "?":
        fl = False
    elif s!='':
        if s[0] == cur:
            cur = s[2]
        elif s[2] == cur:
            cur = s[0]
print(cur)