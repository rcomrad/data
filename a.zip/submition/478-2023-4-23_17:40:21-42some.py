s = []
A = str(input())
n0 = A.count('0')
n1 = A.count('1')
n2 = A.count('2')
n3 = A.count('3')
n4 = A.count('4')
n5 = A.count('5')
n6 = A.count('6')
n7 = A.count('7')
n8 = A.count('8')
n9 = A.count('9')
if n9 > 0:
    s.append('9')
if n8 > 0:
    s.append('8')
if n7 > 0:
    s.append('7')    
if n6 > 0:
    s.append('6')
if n5 > 0:
    s.append('5')
if n4 > 0:
    s.append('4')
if n3 > 0:
    s.append('3')
if n2 > 0:
    s.append('2')
if n1 > 0:
    s.append('1')
if n0 > 0:
    s.append('0')

x = " ".join(s)

print(x)

