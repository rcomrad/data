current_pocket = input()
while True:
    try:
        swap = input()
        if current_pocket in swap:
            current_pocket = swap.replace(current_pocket, "")
    except EOFError:
        break
print(current_pocket)   
