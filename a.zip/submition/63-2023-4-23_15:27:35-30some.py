b=input()
string=input()
sl={b:True}
while string!='?':
    a,b=string.split()
    if a not in sl:
        sl[a]=False
    if b not in sl:
        sl[b]=False
    sl[a],sl[b]=sl[b],sl[a]
    string=input()
for k in sl:
    if sl[k]==True:
        print(k)
