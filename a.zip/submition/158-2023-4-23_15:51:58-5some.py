ls = [int(x) for x in input().split()]

ls.sort()

if ls[0] < 0:
    print('NO')
    exit()

if ls[4] > sum(ls) - ls[4]:
    print('NO')
    exit()

print('YES')
    