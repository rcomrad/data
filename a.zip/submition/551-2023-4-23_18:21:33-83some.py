massive = list(input())
a = massive
score = list()
for i in range(len(massive)-1):
    massive = list(input())
    score.extend(a)
    a = massive
score.extend(a)
print('%.4f' % float(score.count("*")/len(massive)-1))