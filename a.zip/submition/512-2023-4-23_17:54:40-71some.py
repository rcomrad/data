def frequency_sort(items):
    result = []
    for i, x in enumerate(items):
       if i == items.index(x):
          result.extend([x]*items.count(x))
    return result
a = input()
s=[]
for i in range(len(a)):
    if a[i].isdigit() == True:
        s.append(a[i])
d = frequency_sort(s)
d.reverse()
print(*set(d))