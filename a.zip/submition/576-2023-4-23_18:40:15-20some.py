start = input()
b = input().split()
while b[0] != "?" and b[1] != "f":
    if start in b:
        if b.index(start) == 0:
            start = b[1]
        else:
            start = b[0]
    b = input().split()
print(start)