a, b, c, d, e = map(int, input().split())

if a <= b+c+d+e and b <= a+c+d+e and c <= a+b+d+e and d <= a+b+c+e and e <= a+b+c+d:
    print("YES")
else:
    print("NO")





