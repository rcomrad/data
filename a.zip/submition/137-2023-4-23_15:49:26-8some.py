def sortt(nums, num):
    swapped = True
    while swapped:
        swapped = False
        for i in range(len(nums) - 1):
            if nums[i] > nums[i + 1]:
                nums[i], nums[i + 1] = nums[i + 1], nums[i]
                num[i], num[i+1]=num[i+1], num[i]
                swapped = True
s=input()
mas=[0]*10
m=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
for i in s:
    if i in m:
        mas[int(i)]+=1
for i in range(len(m)):
    m[i]=int(m[i])
sortt(mas, m)
s=''
for i in range(9, -1, -1):
    if mas[i]!=0:
        s+=str(m[i])+' '
    else:
        break
print(s)