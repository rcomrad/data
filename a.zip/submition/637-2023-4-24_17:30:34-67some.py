answer = True
triangle = input()
sides = triangle.split()
for i in range(5):
    add = 0
    for j in range(5):
        if j != i:
            add += int(sides[j])
    if add < int(sides[i]):
        answer = False
        break
if answer:
    print("YES")
else:
    print("NO")
