a = []
b = a.count
c = len(a)
d = b / c
print(d)