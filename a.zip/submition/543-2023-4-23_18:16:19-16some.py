a = [int(i) for i in input().split()]
summ = sum(a)
for i in a:
	if i != abs(i) or i > summ - i:
		print("NO")
		break
else:
	print("YES")