num = input()
lst = ['a', 'b', 'c']
lst2 = [False, False, False]
lst2[lst.index(num)] = True
while str != '?':
    str = input()
    if str[0] == num:
        lst2[lst.index(str[-1])] = True
        lst2[lst.index(num)] = False
        num = str[-1]
    elif str[-1] == num:
        lst2[lst.index(str[0])] = True
        lst2[lst.index(num)] = False
        num = str[0]
    else:
        continue
print(num)
