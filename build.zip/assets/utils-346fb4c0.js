function e(){return JSON.parse(localStorage.getItem("user")||"{}")}export{e as G};
