s=list(input())
q=[]
p=dict()
for i in s :
    if i in ['1','2','3','4','5','6','7','8','9','0'] :
        q.append(int(i))
s=sorted(q)[::-1]
z=dict()
for i in s :
    if i in z :
        z[i]+=1
    else:
        z[i]=1
mch=-1234687
for i in z :
    mch=max(mch,z[i])
v=[]
while mch!=0 :
    v=[]
    for i in z :
        if z[i]==mch :
            v.append(i)
    mch-=1
    if v!=[] :
        print(*sorted(v)[::-1],end=' ')
