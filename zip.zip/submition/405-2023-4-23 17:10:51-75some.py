a1=input().split()
a=int(a1[0])
b=int(a1[1])
c=int(a1[2])
d=int(a1[3])
e=int(a1[4])
if a<=0 or b<=0 or c<=0 or d<=0 or e<=0:
    print("NO")
else:
    if a>b+c+d+e:
        print('NO')
    else:
        if b>a+c+d+e:
            print('NO')
        else:
            if c>a+b+d+e:
                print('NO')
            else:
                if d>a+b+c+e:
                    print("NO")
                else:
                    if e>a+b+c+d:
                        print('NO')
                    else:
                        print("YES")