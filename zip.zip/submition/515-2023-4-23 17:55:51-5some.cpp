kolvo_zvezdochek = 0

kolvo_strok = 0

true = True

while true:
    try:
        string = input('')
        kolvo_strok += 1
        len_string = len(string)
        for i in range(len_string):
            if string[i] == '*':
                kolvo_zvezdochek += 1
    except EOFError:
        break

res = kolvo_zvezdochek / kolvo_strok - 1

print(res, end = '0000\n')
