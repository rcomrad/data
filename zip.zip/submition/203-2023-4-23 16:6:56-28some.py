l = list(map(int, input().split()))
f = 0
for i in l:
    s = l[0] + l[1] + l[2] + l[3] + l[4] - i
    if i > s:
        f = 1
if f == 1:
    print('NO')
else:
    print('YES')