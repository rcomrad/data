import sys
from queue import Queue
import math
import time

#    a = [int(xx) for xx in input().split()]
input = sys.stdin.readline
# print = lambda x: sys.stdout.write(str(x) + '\n')

s = input()[:-1]
n = len(s)


def cnt(x):
    res = 0
    for ch in x:
        if ch == "*":
            res += 1
    return res


ans = cnt(s)


st = time.time()
while True:
    s = input()
    d = cnt(s)
    ans += d

    if time.time() - st > 0.5:
        break

print(ans / n - 1)

