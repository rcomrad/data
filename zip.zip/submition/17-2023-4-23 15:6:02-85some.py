a = list(map(int,input().split()))
flag = False
if max(a) > sum(a)-max(a) or min(a) < 0:
    print('NO')
    flag = True
else:
    print('YES')