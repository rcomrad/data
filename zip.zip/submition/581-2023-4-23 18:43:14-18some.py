sas = [list(map(str, input()))]
s = 0
for i in range(len(sas[0]) - 1):
    sas.append(list(map(str, input())))
for i in range(len(sas)):
    s += sas[i].count('*')
print(round(((s / len(sas[0])) -1),4))