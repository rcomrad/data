initial_pocket = input()
exchanges = []
while True:
    exchange = input()
    if exchange == "?":
        break
    exchanges.append(exchange.split())

prize_pocket = initial_pocket
for a, b in exchanges:
    if a == prize_pocket:
        prize_pocket = b
    elif b == prize_pocket:
        prize_pocket = a
print(prize_pocket)