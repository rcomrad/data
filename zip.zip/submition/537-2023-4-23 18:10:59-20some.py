qweqwe = input().split()
a = [int(i) for i in qweqwe]
maxo = max(a)
d = a.index(maxo)
suma = 0
for i in range(len(a)):
    suma += a[i]
if maxo <= (suma - maxo):
    print("YES")
else:
    print("NO")