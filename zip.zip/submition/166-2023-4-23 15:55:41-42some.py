n1, n2, n3, n4, n5 = map(int, input().split())
num1 = ""
num2 = ""
num3 = ""
num4 = ""
num5 = ""
if n1 > n2+n3+n4+n5:
    num1 = "N"
else:
    num1 = "Y"
if n2 > n1+n3+n4+n5:
    num2 = "N"
else:
    num2 = "Y"
if n3 > n2+n1+n4+n5:
    num3= "N"
else:
    num3 = "Y"
if n4 > n2+n3+n1+n5:
    num4 = "N"
else:
    num4 = "Y"
if n5 > n2+n3+n4+n1:
    num5 = "N"
else:
    num5 = "Y"

if num1+num2+num3+num4+num5 == "YYYYY":
    print("YES")
else:
    print("NO")


