n = list(input())
num = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
a = {}
for i in n:
    if i in num:
        a[i] = n.count(i)
a = dict(sorted(a.items()))
a = {k: a[k] for k in sorted(a, key=a.get, reverse=True)}
for i in a:
    print(i, end=' ')
