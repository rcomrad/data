a, b, c, d, e = map(int, input().split())
ls = [a, b, c, d, e]
for i in range(5):
    if ls[i] < 0 or ls[i] > sum(ls[:i]) + sum(ls[i+1:]):
        print("NO")
        exit()
print("YES")
