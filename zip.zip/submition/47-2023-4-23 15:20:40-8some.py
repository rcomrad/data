s=input()
mas=[]
mmm=[]
k=input()
while k!='?':
    mas.append(k)
    if k[0] not in mmm:
        mmm.append(k[0])
    if k[2] not in mmm:
        mmm.append(k[2])
    k=input()
m={}
for i in mmm:
    m[i]=0
m[s]=1
for i in mas:
    m[i[0]], m[i[2]]=m[i[2]], m[i[0]]
for key, value in m.items():
    if value==1:
        print(key)