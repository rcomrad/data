#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;


int main()
{
    int n, m;
    cin >> n >> m;
    std::vector<std::string> a(n);
    std::getline(cin, a[0]);
    for (auto& i : a)
    {
        std::getline(cin, i);
    }

    std::queue<std::pair<int, int>> q;
    for (int i = 0; i < a.size(); ++i)
    {
        for (int j = 0; j < a[i].size(); ++j)
        {
            if (a[i][j] == 'S')
            {
                q.push({i, j});
            }
        }
    }

    bool finish = false;
    int chese   = 0;
    int dx[]    = {1, -1, 0, 0};
    int dy[]    = {0, 0, 1, -1};
    while (!q.empty())
    {
        auto cur = q.front();
        q.pop();
        if (cur.first < 0 || cur.first >= n) continue;
        if (cur.second < 0 || cur.second >= m) continue;

        auto& temp = a[cur.first][cur.second];
        if (temp == '*') continue;
        if (temp == 'F') finish = true;
        if (temp == 'C') chese += 1;
        temp = '*';

        for (int i = 0; i < 4; ++i)
        {
            q.push({cur.first + dx[i], cur.second + dy[i]});
        }
    }

    if (!finish) chese = 0;
    cout << chese;
}
