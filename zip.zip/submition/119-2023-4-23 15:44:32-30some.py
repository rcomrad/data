a=input()
b=[0]*10
for i in a:
    if i.isdigit():
        b[int(i)]+=1
c=[]
for i in range(10):
    if b[i]>0:
        c.append([b[i],i])
c.sort(reverse=True)
for i in c:
    print(i[1], end=' ')
    
