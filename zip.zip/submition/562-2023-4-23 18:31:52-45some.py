a = input()
b = []
c = input().split()
while c != ["?"]:
    b.append(c)
    c = input().split()
for i in range(len(b)):
    if a in b[i]:
        for j in range(2):
            if a != b[i][j]:
                a = b[i][j]
                break
print(a)
