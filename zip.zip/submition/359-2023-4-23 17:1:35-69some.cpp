def a1(a):
    for i in range(len(a)-1):
        for j in range(len(a)-i-1):
            if a[j] > a[j+1]:
                (a[j],a[j+1]) = (a[j+1],a[j])
    return a

a=input()
b=[]
c=['0','1','2','3','4','5','6','7','8','9']
d={}
for i in range(len(a)):
    if a[i] in c:
        if a[i] in d:
            d[a[i]]=d[a[i]]+1
        else:
            d[a[i]]=1
            b.append(a[i])
e=[]
for i in range(len(b)):
    e.append([d[b[i]],b[i]])
e=a1(e)
for i in range(len(e)-1,-1,-1):
    print(e[i][1],end=" ")