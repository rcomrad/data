a = [int(i) for i in input().split()]
for i in range(5):
	if a[i] > sum(a) - a[i] or a[i] < 0:
		print('NO')
		exit()
print('YES')