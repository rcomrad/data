a = list(map(int, input().split()))
a.sort()
if a[4] > sum(a) - a[4] or min(a) < 0:
    print('NO')
else:
    print('YES')