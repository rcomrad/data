sides = list(map(int, input().split()))

if max(sides) <= sum(sides) - max(sides) and all(side >= 0 for side in sides):
    print("YES")
else:
    print("NO")