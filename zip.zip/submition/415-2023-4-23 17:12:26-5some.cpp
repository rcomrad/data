#include <iostream>
#include <fstream>
// #include <bits/stdc++.h>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <deque>
#include <string>
#include <algorithm>
#include <utility>
#include <cmath>

// #define вектор vector
// #define стринг string
// #define инт int
// #define труе true
// #define фалсе false
// #define иф if
// #define елсе else
// #define саут cout
// #define вайл while
// #define тожесамое ==

// #define make_and_input_len_ls_and_ls int len_ls; cin >> len_ls; \
//         vector <int> ls(len_ls); for (int i = 0; i < len_ls; i++) cin >> ls[i];
// #define make_and_input_ls(ls, len_ls) __vi ls(len_ls); myforip(len_ls) { cin >> ls[i]; ls[i]--; }
// #define __inp(x) cin >> x
// #define m_p(x, y) make_pair(x, y)
// #define pii pair <int, int>
// #define ff first
// #define ss second
// #define all(x) x.begin(), x.end()
// #define __vc vector <char>
// #define __vb vector <bool>
// #define __vi vector <int>
// #define __vll vector <ll>
// #define __vs vector <string>
// #define __vvi vector <vector <int>>
// #define __vvll vector <vector <ll>>
// #define __vvc vector <vector <char>>
// #define myforip(l, r)   for (int i = l; i < r; i++)
// #define myforjp(l, r)   for (int j = l; j < r; j++)
// #define myforp(i, l, r) for (ll i = l; i < r; i++)
// #define myform(i, l, r) for (int i = l; i > r; i--)

// #define PI 3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986
// #define INF 1000000001

// typedef long long ll;
// typedef unsigned long long ull;

using namespace std;

// char from_int_to_char(int elem) {
//     return '0' + elem;
// }

// bool is_digit(char digit) {
//     bool is_digit = false;
//     for (int i = 0; i < 10; i++) {
//         if (digit == from_int_to_char(i)) {
//             is_digit = true;
//         }
//     }
//     return is_digit;
// }

// int int_char(char ch) {
//     return (int) ch - '0';
// }

// template <typename T>
// void printls(vector <T> ls, int len_ls) {
//     if (len_ls == 0) {
//         return;
//     }
//     myforp(i, 0, len_ls - 1) {
//         cout << ls[i] << " ";
//     }
//     cout << ls[len_ls - 1] << endl;
// }

// template <typename T>
// void print(T elem) {
//     cout << elem << endl;
// }

// template <typename T>
// void justprint(T elem) {
//     cout << elem;
// }

// template <typename T>
// T myinput() {
//     T elem;
//     cin >> elem;
//     return elem;
// }

// stoi для int, а stoll для long long

int main() {
    double kolvo_strok = 0, kolvo_zvezdochek = 0;
    int len_str;

    string str;

    while (cin >> str) {
        kolvo_strok++;
        len_str = str.size();
        for (int i = 0; i < len_str; i++) {
            if (str[i] == '*') {
                kolvo_zvezdochek++;
            }
        }
    }

    double res = kolvo_zvezdochek / kolvo_strok - 1;

    cout << res << "\n";
}

// int main() {
//     cin.tie(0);
//     cout.tie(0);
//     ios_base::sync_with_stdio(false);

//     int t = 1;
//     // cin >> t;
//     while (t--) {
//         solve();
//     }
// }
