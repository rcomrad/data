s=[int(i) for i in input().split()]
v=sum(s)
for i in s :
    if i>(v-i) :
        print("NO")
        exit()
print("YES")
