k=input()
while True :
    n=input().split()
    if n==["?"] :
        print(k)
        exit()
    if n[0]==k :
        k=n[1]
    elif n[1]==k :
        k=n[0]
