numbs = [symb for symb in input() if symb in "0123456789"]
counter = {}
for numb in set(numbs):
    counter[numb] = numbs.count(numb)
print(*sorted(counter, key=lambda x: (counter[x], int(x)), reverse=True))