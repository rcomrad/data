kol=0
s=input()
n=len(s)
for i in range(n):
    l=0
    for j in s:
        kol+=int(j=='*')
        l+=1
    try:
        s=input()
    except :
        n
    else:
        continue
    finally:
        n
print(kol/l-1)