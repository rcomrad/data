sides = input().split()
a, b, c, d, e = int(sides[0]), int(sides[1]), int(sides[2]), int(sides[3]), int(sides[4])
error = 0
if a > (b + c + d +e) or a < 0 or a % b == 0 or a % c == 0 or a % d == 0 or a % e == 0:
    error += 1
elif b > (a + c + d + e) and b < 0 or b % a == 0 or b % c == 0 or b % d == 0 or b % e == 0:
    error += 1
elif c > (a + b + d + e) and c < 0 or c % a == 0 or c % b == 0 or c % d == 0 or c % e == 0:
    error += 1
elif d > (a + b + c + e) and d < 0 or d % a == 0 or d % b == 0 or d % c == 0 or d % e == 0:
    error += 1
elif e > (a + b + c + d) and e < 0 or e % a == 0 or e % b == 0 or e % c == 0 or e % d == 0:
    error += 1
if error != 0:
    print('NO')
else:
    print('YES')

    