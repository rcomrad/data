
count = 0
for i in range(4):
    x = input()
    for j in x:
        if j == '*':
            count+=1
res = str(count/4-1)
flag = False
itog = ''
count = 0
for i in res:
    itog+=str(i)
    if flag == True:
        count+=1
    if str(i) == '.':
        flag = True
    if count == 4:
        print(itog)
        break

if count < 4:
    itog+='0'*(4-count)
    print(itog)

