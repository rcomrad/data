from collections import deque

n, m = map(int, input().split())
maze = [input() for _ in range(n)]

start = None
for i in range(n):
    for j in range(m):
        if maze[i][j] == 'S':
            start = (i, j)
            break

visited = set()
queue = deque([start])
cheese_count = 0

while queue:
    node = queue.popleft()
    if node in visited:
        continue
    visited.add(node)

    i, j = node
    if maze[i][j] == 'C':
        cheese_count += 1
        maze[i] = maze[i][:j] + ' ' + maze[i][j+1:]

    if maze[i][j] == 'F':
        print(cheese_count)
        break

    for x, y in [(i-1, j), (i+1, j), (i, j-1), (i, j+1)]:
        if 0 <= x < n and 0 <= y < m and maze[x][y] != '*':
            queue.append((x, y))
