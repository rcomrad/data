# data = {}
# pocket_with_sock = input().lower()  # имя кармана, в котором лежит носок
# data[pocket_with_sock] = 1
# while True:
#     change = input().lower()
#     if change == '?':
#         break
#     x, y = change.split()
#     # заполняем данные
#     if x not in data:
#         data[x] = 0
#     if y not in data:
#         data[y] = 0
#     # обработка замены
#     temp_x = data[x]
#     data[x] = data[y]
#     data[y] = temp_x
#
# for el in data:
#     if data[el] == 1:
#         print(el.lower())
#         break
pocket = input() # вводим начальный карман
swaps = [] # создаем пустой список для хранения пар карманов
while True:
    s = input()
    if s == "?": # если встретили знак вопроса, то прекращаем ввод данных
        break
    swaps.append(s.split()) # добавляем пару карманов в список swaps
for swap in swaps: # меняем местами содержимое карманов по каждой паре
    if pocket == swap[0]:
        pocket = swap[1]
    elif pocket == swap[1]:
        pocket = swap[0]
print(pocket)