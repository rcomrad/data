import sys
from queue import Queue
import math

#    a = [int(xx) for xx in input().split()]
input = sys.stdin.readline
# print = lambda x: sys.stdout.write(str(x) + '\n')


a = [int(xx) for xx in input().split()]

a.sort()

if a[0] < 1 or a[0] + a[1] + a[2] + a[3] < a[4]:
    print("NO")
else:
    print("YES")