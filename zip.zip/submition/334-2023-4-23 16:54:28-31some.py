a=input()
b={}

for i in list(a):
    if i in "0123456789":
        if i in b:
            b[i]+=1
        else:
            b[i]=1
def get_key(d, value):
    for k, v in d.items():
        if v == value:
            return k
c = list(b.values())
c.sort()
c.reverse()
for i in c:
    print(get_key(b,i), end=" ")