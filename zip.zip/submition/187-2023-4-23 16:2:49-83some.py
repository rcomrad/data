prize = input()
a = 0
b = 0
c = 0
if prize == 'b':
    b = 1
elif prize == 'c':
    c = 1
else:
    a = 1
pare = input()
while pare != "?":
    pare = pare.split()
    if (pare[1] == 'b' and pare[0] == 'c') or (pare[1] == 'c' and pare[0] == 'b') :
        b, c = c, b
    elif (pare[1] == 'a' and pare[0] == 'c') or (pare[1] == 'c' and pare[0] == 'a') :
        a, c = c, a
    else:
        b, a = a, b
    pare = input("")
if a ==1: print('a')
elif b == 1: print('b')
else: print('c')