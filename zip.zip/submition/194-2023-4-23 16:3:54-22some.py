a, b, c, d, e = map(int, input().split())
if a > (b + c + d + e):
    x = False
elif b > (a + c + d + e):
    x = False
elif c > (a + b + d + e):
    x = False
elif d > (a + c + b + e):
    x = False
elif e > (a + c + d + b):
    x = False
else:
    x = True


if a < 0:
    x = False
elif b < 0:
    x = False
elif c < 0:
    x = False
elif d < 0:
    x = False
elif e < 0:
    x = False


if x == True:
    print("YES")
if x == False:
    print("NO")
