a = [input() for x in range(4)]
n = max([len(b) for b in a])

a = "".join(a).count("*")

print(f"{round(a / n - 1, 4):.04f}")