arr = [int(q) for q in input().split()]
m = max(arr)
if 2*m <= sum(arr):
    print("YES")
else:
    print("NO")