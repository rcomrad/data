stroka = input()
k0 = 0
k1 = 0
k2 = 0
k3 = 0
k4 = 0
k5 = 0
k6 = 0
k7 = 0
k8 = 0
k9 = 0
for i in range(len(stroka)):
    if stroka[i] == "0":
        k0 += 1
    elif stroka[i] == "1":
        k1 += 1
    elif stroka[i] == "2":
        k2 += 1
    elif stroka[i] == "3":
        k3 += 1
    elif stroka[i] == "4":
        k4 += 1
    elif stroka[i] == "5":
        k5 += 1
    elif stroka[i] == "6":
        k6 += 1
    elif stroka[i] == "7":
        k7 += 1
    elif stroka[i] == "8":
        k8 += 1
    elif stroka[i] == "9":
        k9 += 1

listik = []
listik.append(k0)
listik.append(k1)
listik.append(k2)
listik.append(k3)
listik.append(k4)
listik.append(k5)
listik.append(k6)
listik.append(k7)
listik.append(k8)
listik.append(k9)
listik.sort(reverse=True)
res1 = ""
for i in range(len(listik)):

    if listik[i] == k9 and listik[i] > 0:
        res1 += "9 "
        k9 = 0
    if listik[i] == k8 and listik[i] > 0:
        res1 += "8 "
        k8 = 0
    if listik[i] == k7 and listik[i] > 0:
        res1 += "7 "
        k7 = 0
    if listik[i] == k6 and listik[i] > 0:
        res1 += "6 "
        k6 = 0
    if listik[i] == k5 and listik[i] > 0:
        res1 += "5 "
        k5 = 0
    if listik[i] == k4 and listik[i] > 0:
        res1 += "4 "
        k4 = 0
    if listik[i] == k3 and listik[i] > 0:
        res1 += "3 "
        k3 = 0
    if listik[i] == k2 and listik[i] > 0:
        res1 += "2 "
        k2 = 0
    if listik[i] == k1 and listik[i] > 0:
        res1 += "1 "
        k1 = 0
    if listik[i] == k0 and listik[i] > 0:
        res1 += "0 "
        k0 = 0
res0 = res1.rstrip()
print(res0)