st = 0
result = 0
while str != '':
    str = input()
    st += 1
    result += str.count('*')
import math
result = result / (st-1)
result = round(result, 4)
print(float("{0:.4f}".format(result-1)))