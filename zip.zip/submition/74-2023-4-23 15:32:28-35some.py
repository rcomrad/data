soob = list(map(str, input().split("")))
kol1 = 0
kol2 = 0
kol3 = 0
kol4 = 0
kol5 = 0
kol6 = 0
kol7 = 0
kol8 = 0
kol9 = 0
kol0 = 0
for i in range(len(soob)):
    if soob[i] == "1":
        kol1 += 1
    if soob[i] == "2":
        kol2 += 1
    if soob[i] == "3":
        kol3 += 1
    if soob[i] == "4":
        kol4 += 1
    if soob[i] == "5":
        kol5 += 1
    if soob[i] == "6":
        kol6 += 1
    if soob[i] == "7":
        kol7 += 1
    if soob[i] == "8":
        kol8 += 1
    if soob[i] == "9":
        kol9 += 1
    if soob[i] == "0":
        kol0 += 1
maxx = list[max(kol1, kol2, kol3, kol4, kol5, kol6, kol7, kol8, kol9, kol0)]
maxx.sort().reverse()
