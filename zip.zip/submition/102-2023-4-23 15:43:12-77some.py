from collections import deque

n, m = map(int, input().split())
maze = [input() for _ in range(n)]

start = None
for i in range(n):
    for j in range(m):
        if maze[i][j] == 'S':
            start = (i, j)

q = deque([start])
visited = set([start])
cheese_count = 0

while q:
    curr_i, curr_j = q.popleft()
    curr_char = maze[curr_i][curr_j]
    
    if curr_char == 'F':
        print(cheese_count)
        break
    
    if curr_char == 'C':
        cheese_count += 1
        
    for ni, nj in [(curr_i-1, curr_j), (curr_i+1, curr_j), (curr_i, curr_j-1), (curr_i, curr_j+1)]:
        if 0 <= ni < n and 0 <= nj < m and maze[ni][nj] != '*' and (ni, nj) not in visited:
            visited.add((ni, nj))
            q.append((ni, nj))
