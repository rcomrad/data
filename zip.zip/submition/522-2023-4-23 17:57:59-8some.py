s=input()
per=s
k=input()
while k!='?':
    if k[0]==per or k[2]==per:
        if per==k[2]:
            per=k[0]
        else:
            per=k[2]
    k=input()
print(per)