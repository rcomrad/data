i = ord(input())
m = []
for k in range(97, 123):
    if k != i:
        m.append(0)
    else:
        m.append(1)

arr = input().split()

while ( arr[0] != '?'):
    (j,k) = (ord(arr[0])-97,ord(arr[1]) - 97)
    (m[j],m[k]) = (m[k],m[j])
    arr = input().split()

for k in range(26):
    if m[k] == 1:
        print (chr(k+97).lower())