s = input()
x = input()
while x != "?":
    a,b = x.split()
    if a == s:
        s =  b
    elif b == s:
        s = a
    x = input()
print(s)