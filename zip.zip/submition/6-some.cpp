#include <cstdio>
 
int main()
{
	while(true);
}
