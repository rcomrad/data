a,b,c,d,e = input().split()
if a > (b + c + d + e) or b > (a + c + d + e) or c > (b + a + d + e) or d > (b + c + a + e) or e > (b + c + d + a):
    print("YES")
else:
    print("NO")
    
