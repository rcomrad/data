ls = list(input())
ans = ""
x = -1
numbers = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
arr = [[0, "0"], [0, "1"], [0, "2"], [0, "3"], [0, "4"], [0, "5"], [0, "6"], [0, "7"], [0, "8"], [0, "9"]]
for i in range(len(ls)):
    if ls[i] in numbers:
        arr[int(ls[i])][0] += 1
arr.sort()
while arr[x][0] != 0:
    if ans == "":
        ans = arr[x][1]
        x -= 1
    else:
        ans += " "
        ans += arr[x][1]
        x -= 1
print(ans)
