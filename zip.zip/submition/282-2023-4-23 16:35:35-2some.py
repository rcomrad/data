s = input()
a = {}
for i in s:
    if not i.isdigit():
        continue
    i = int(i)
    if i not in a:
        a[i] = 1
    else:
        a[i]+=1
a = list(a.items())
a.sort(key = lambda x : x[0])
a.sort(key = lambda x : -x[1])
b = [x[0] for x in a]
print(*b)
