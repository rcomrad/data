a = [int(i) for i in input().split()]
for i in range(5):
    if a[i] < 0:
        print("NO")
        exit()
    elif a[i] > sum(a[:i]) + sum(a[i + 1:]):
        print("NO")
        exit()
print("YES")
