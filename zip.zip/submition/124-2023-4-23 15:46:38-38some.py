s = [i for i in input()]
s_new = []
for i in s:
    if i in '1234567890':
        s_new.append(int(i))
s = s_new.copy()
ss = set(s)
ss = list(ss)
ss1 = []
for i in ss:
    a = s.count(i)
    ss1.append(a)
m = max(ss1)
i = 0
q = []
for i in range(len(ss1)):
    if ss1[i] == m:
        q.append(ss[i])
q.sort(reverse=True)
print(*q)
