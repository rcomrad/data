num = input()
lst = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
lst2 = [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False]
lst2[lst.index(num)] = True
while str != '?':
    str = input()
    if str[0] == num:
        lst2[lst.index(str[-1])] = True
        lst2[lst.index(num)] = False
        num = str[-1]
    elif str[-1] == num:
        lst2[lst.index(str[0])] = True
        lst2[lst.index(num)] = False
        num = str[0]
    else:
        continue
print(num)