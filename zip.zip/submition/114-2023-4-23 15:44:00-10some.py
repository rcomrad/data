a, b, c, d, e = map(int, input().split())
if a < 0 or b < 0 or c < 0 or d < 0 or e < 0:
    print("NO")
elif a > b + c + d + e or b > a + c + d + e or c > a + b + d + e or d > a + b + c + e or e > a + b + c + d:
    print("NO")
else:
    print("YES")
