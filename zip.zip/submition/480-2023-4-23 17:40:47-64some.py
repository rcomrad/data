def issum5(a,b,c,d,e):
    if a <= b+c+d+e:
        return True
    return False
a,b,c,d,e = map(int,input().split())
p = max(max(max(max(a,b),c),d),e)
if issum5(a, b, c, d, e) and issum5(b, a, c, d, e) and issum5(c, b, a, d, e) and issum5(d, b, c, a, e):
    if p % b==0 and p % a == 0 and p % c == 0 and p % d == 0 and p % e == 0:
        print('YES')
    else:
        print('NO')
else:
    print('NO')