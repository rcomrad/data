data = {}
pocket_with_sock = input()  # имя кармана, в котором лежит носок
data[pocket_with_sock] = 1
while True:
    change = input()
    if change == '?':
        break
    x, y = change.split()
    # заполняем данные
    if x not in data:
        data[x] = 0
    if y not in data:
        data[y] = 0
    # обработка замены
    temp_x = data[x]
    data[x] = data[y]
    data[y] = temp_x

for el in data:
    if data[el] == 1:
        print(el)
        break
