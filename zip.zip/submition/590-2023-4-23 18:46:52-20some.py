s = input()
freq = {}
for ch in s:
    if ch.isdigit():
        freq[ch] = freq.get(ch, 0) + 1
sorted_freq = sorted(freq.items(), key=lambda x: x[1], reverse=True)
for item in sorted_freq:
    print(item[0], end=' ')