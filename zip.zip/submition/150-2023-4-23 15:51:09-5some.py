from collections import Counter

symb = input('')

dc_counter = Counter()

dc_counter[symb] = 1

true = True

while true:
    str_inp = input('')
    if str_inp == '?':
        break
    symb_from, symb_to = str_inp.split()
    dc_counter[symb_from], dc_counter[symb_to] = dc_counter[symb_to], dc_counter[symb_from]

for key in dc_counter:
    if dc_counter[key] == 1:
        print(key)
