summ = 0

while True :
	a = input()
	summ += a.count("*")
	if a == "*" * len(a):
		break
s = str(float(summ / len(a) - 1))

print(s + "0"*(4 - len(s.split(".")[1])))