a=list(map(int,input().split()))
if a[0]<=a[1]+a[2]+a[3]+a[4] and a[1]<=a[0]+a[2]+a[3]+a[4] and a[2]<=a[1]+a[0]+a[3]+a[4] and a[3]<=a[1]+a[2]+a[0]+a[4] and a[4]<=a[1]+a[2]+a[3]+a[0] and sum(a)%a[0]==0 and sum(a)%a[1]==0 and sum(a)%a[2]==0 and sum(a)%a[3]==0 and sum(a)%a[4]==0 and a[0]>0 and a[1]>0 and a[2]>0 and a[3]>0 and a[4]>0:
    print("YES")
else:
    print("NO")
