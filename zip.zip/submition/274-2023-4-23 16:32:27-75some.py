import sys
matrix=[]
kr=0
for line in sys.stdin:
    mew=[]
    # rstrip('\n') "отрезает" от строки line идущий справа символ
    # перевода строки, ведь print сам переводит строку
    
    for i in range(len(line)):
        for j in range(len(line[i])):
            if line[i][j]==" ":
                mew.append(" ")
            else:
                if line[i][j]=="*":
                    mew.append("*")
                    kr+=1
    matrix.append(mew)
are=len(matrix[len(matrix)-1])
otvet=(kr/are)-1
print('{0:.4f}'.format(otvet))