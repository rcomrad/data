qweqwe = input().split()
a = [int(i) for i in qweqwe]
maxo = max(a)
d = a.index(maxo)
suma = 0
c = 0
for i in range(len(a)):
    suma += a[i]
    if a[i]<0:
        c += 1
if maxo <= (suma - maxo) and c == 0:
    print("YES")
elif c != 0:
    print("NO")
else:
    print("NO")