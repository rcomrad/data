import string

d = dict.fromkeys(string.ascii_lowercase, 0)
a = input()
d[a] = 1
while True:
    x = [i for i in input().split()]
    if x[0] == '?':
        break
    c = d[x[0]]
    d[x[0]] = d[x[1]]
    d[x[1]] = c
print(list(d.keys())[list(d.values()).index(1)])

