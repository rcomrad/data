bag = input()
while (symbs := input()) != "?":
    symbs = symbs.split()
    if bag in symbs:
        symbs.remove(bag)
        bag = symbs[0]
print(bag)