st = [int(i) for i in input().split()]
maxim = max(st)
s = 0
for elem in st:
    if elem != maxim:
        s += elem
if maxim <= s:
    print('YES')
else:
    print('NO')
