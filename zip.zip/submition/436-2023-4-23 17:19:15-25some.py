a = input()
a=''.join(i for i in a if i.isdigit())
arr=[]
for i in range(len(a)):
    arr.append(int(a[i]))
arr.sort()
s=list(set(arr))
l=[]
for i in range(len(s)):
    l.append(arr.count(s[i]))
f=[]

#print(l, s)
while len(l)>0:
    z=l.index(max(l))
    #print(z, max(l))
    f.append(s[z])
    del l[z]
print(*f)
