﻿#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <math.h>
#include <set>
#include <cmath>
#include <queue>
#include <deque>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef vector<int> vi;
typedef pair<int, int> pi;

#define forn(i, a, b)  for (int i = a; i < b; i++)
#define fin(a, v)      for (auto a : v)

//#pragma GCC optimize("O3,unroll-loops")
//#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")

#define all(v) ((v).begin()), ((v).end())
#define mn(v) *min_element(all(v))
#define mx(v) *max_element(all(v))

#define pb push_back
#define ff first
#define ss second

const ll inf = 1e18;

const pair<int, int> nx8[] = { {0, 1}, {1, 0}, {0, -1}, {-1, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1} };
const pair<int, int> nx4[] = { {0, 1}, {1, 0}, {0, -1}, {-1, 0} };

inline void solve_();

inline int
__lg(int __n)
{
    return (int)log2(__n);
}

template<typename T1, typename T2>
ostream& operator<<(ostream& out, const pair<T1, T2>& p) {
    out << p.ff << ' ' << p.ss;
    return out;
}
template<typename T1, typename T2>
istream& operator>>(istream& in, pair<T1, T2>& p) {
    in >> p.ff >> p.ss;
    return in;
}
template<typename T1, typename T2>
pair<T1, T2> operator+(pair<T1, T2> a, pair<T1, T2>& b) {
    a.ff += b.ff, a.ss += b.ss;
    return a;
}


template<typename T>
ostream& operator<<(ostream& out, const vector<T>& v) {
    for (auto& el : v) out << el << ' ';
    return out;
}
template<typename T>
istream& operator>>(istream& in, vector<T>& v) {
    for (auto& el : v) in >> el;
    return in;
}


template<typename T>
ostream& operator<<(ostream& out, const set<T>& s) {
    for (auto& el : s) out << el << ' ';
    return out;
}


template<typename T1, typename T2>
ostream& operator<<(ostream& out, const map<T1, T2>& m) {
    for (auto& el : m) out << el << '\n';
    return out;
}


template<typename T>
T sum(const vector<T>& v) {
    T res = 0;
    for (auto& i : v) res += i;
    return res;
}


template<typename T>
T bin_search(const vector<T>& v, T x) {
    ll l = 0, r = (ll)v.size() - 1;
    while (r - l > 1) {
        ll m = (l + r) / 2;
        if (v[m] > x) r = m;
        else l = m;
    }
    return l;
}

ll pow(ll a, ll k) {
    if (k == 0) return 1;
    if (k % 2 == 0) return pow(a * a, k / 2);
    return a * pow(a, k - 1);
}


/*
    O(n log n + n2)


  1 2 3 4
0 1 3 6 10

    sum(i, j) = pref[j] - pref[i - 1]
*/


vector<vector<ll>> rmq;

void construct_of_rmq(vector<ll>& v, const string& s) {
    ll n = (ll)v.size();
    rmq.resize(__lg(n) + 1, vector<ll>(n));
    for (ll i = 0; i < n; i++) {
        rmq[0][i] = v[i];
    }
    for (ll i = 1; i <= __lg(n); i++) {
        ll j = 0;
        while (true) {
            if (j + (1 << (i - 1)) >= n) {
                break;
            }
            if (s == "min") {
                rmq[i][j] = min(rmq[i - 1][j], rmq[i - 1][j + (1 << (i - 1))]);
                j++;
            }
            else if (s == "max") {
                rmq[i][j] = max(rmq[i - 1][j], rmq[i - 1][j + (1 << (i - 1))]);
                j++;
            }
            else {
                return;
            }
        }
    }
}

ll ans_of_rmq(ll l, ll r, const string& s) {
    ll p = __lg(r - l);
    ll ans;
    if (s == "min") {
        ans = min(rmq[p][l], rmq[p][r - (1 << p) + 1]);
    }
    else if (s == "max") {
        ans = max(rmq[p][l], rmq[p][r - (1 << p) + 1]);
    }
    else {
        ans = -inf;
    }
    return ans;
}

/*
void bfs(int n, const vector<vi> &g, const vi &start) {
    queue<int> q;
    vector<int> d(n, -1);

    fin(v, start) {
        d[v] = 0;
        q.push(v);
    }

    while (!q.empty()) {
        int v = q.front();
        q.pop();

        fin(u : g[v]) {
            if (q[])
        }
    }
}
*/

vector<int> topsort(int n, const vector<vi>& g) {
    queue<int> q;
    vector<int> w(n);

    forn(v, 0, n) {
        fin(u, g[v]) {
            w[u]++;
        }
    }

    forn(v, 0, n) {
        if (w[v] == 0) {
            q.push(v);
        }
    }

    vector<int> topres;

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        topres.pb(v);

        fin(u, g[v]) {
            w[u]--;
            if (w[u] == 0) {
                q.push(u);
            }
        }
    }
    return topres;
}

vector<vi> _g;
vector<bool> _used;
vi _topG;

void _dfs_topsort(int v) {
    _used[v] = true;

    for (int u : _g[v]) {
        if (!_used[u]) {
            _dfs_topsort(u);
        }
    }
    _topG.pb(v);
}

vi topsort2(int n, const vector<vi>& g) {
    _g = g;

    _used.clear();
    _used.resize(n, false);

    _topG.clear();

    forn(i, 0, n) {
        if (!_used[i]) {
            _dfs_topsort(i);
        }
    }

    reverse(all(_topG));

    return _topG;
}


int _cnt;
vector<vi> _revG;
vector<int> _cmps;

void _dfs(int v) {
    _cmps[v] = _cnt;

    fin(u, _revG[v]) {
        if (_cmps[u] == -1) {
            _dfs(u);
        }
    }
}


vector<int> comps(int n, const vector<vi>& g) {
    vi topG = topsort2(n, g);

    _revG.clear();
    _revG.resize(n);
    forn(v, 0, n) {
        fin(u, g[v]) {
            _revG[u].pb(v);
        }
    }

    _cnt = 0;
    _cmps.resize(n, -1);

    fin(i, topG) {
        if (_cmps[i] == -1) {
            _cnt++;
            _dfs(i);
        }
    }

    return _cmps;
}


#define multitask_
signed main() {
    //    freopen("cycle.in", "r", stdin);
    //    freopen("cycle.out", "w", stdout);
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cout.precision(40);

    int32_t tt = 1;

#ifdef multitask_
 //   cin >> tt;
#endif
    while (tt--) solve_();
    return 0;
}

int n, m;
vector<vector<char>> mp;
vector<vector<bool>> used;

vector<pi> ways = { {1, 0}, {0, 1}, {-1, 0}, {0, -1} };

ll cnt = 0;
bool flag = false;

bool check(int r, int c) {
    if (r < 0 || r >= n || c < 0 || c >= m) {
        return false;
    }
    if (mp[r][c] == '*') {
        return false;
    }
    return true;
}

void dfs(pi v) {
    used[v.ff][v.ss] = true;

    if (mp[v.ff][v.ss] == 'C') {
        cnt++;
    }
    else if (mp[v.ff][v.ss] == 'F') {
        flag = true;
    }

    for (pi nx : ways) {
        pi u = v + nx;

        if (check(u.ff, u.ss) && !used[u.ff][u.ss]) {
            dfs(u);
        }
    }
}


inline void solve_() {
    cin >> n >> m;


    used.resize(n, vector<bool>(m, false));
    mp.resize(n, vector<char>(m));

    string s;
    getline(cin, s);

    pi start;

    for (int r = 0; r < n; r++) {
        getline(cin, s);
        for (int c = 0; c < m; c++) {
            mp[r][c] = s[c];
            
            if (mp[r][c] == 'S') {
                start = { r, c };
            }
        }
    }

    dfs(start);

    if (flag) {
        cout << cnt;
    }
    else {
        cout << cnt;
    }

}
