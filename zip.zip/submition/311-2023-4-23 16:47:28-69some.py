a,b=map(int,input().split())
d=[]
for i in range(a):
    c=input()
    e=[]
    for j in range(b):
        if c[j]=="*":
            e.append(2)
        if c[j]==" ":
            e.append(0)
        if c[j]=="S":
            e.append(1)
        if c[j]=="C" or c[j]=="F":
            e.append(3)
    d.append(e)
otv=0
for i in range(a+b):
    for i in range(1,a-1,1):
        for j in range(1,b-1,1):
            if d[i][j]==1:
                if d[i+1][j]!=2:
                    if d[i+1][j]==3:
                        otv=otv+1
                    d[i+1][j]=1
                if d[i-1][j]!=2:
                    if d[i-1][j]==3:
                        otv=otv+1
                    d[i-1][j]=1
                if d[i][j+1]!=2:
                    if d[i][j+1]==3:
                        otv=otv+1
                    d[i][j+1]=1
                if d[i][j-1]!=2:
                    if d[i][j-1]==3:
                        otv=otv+1
                    d[i][j-1]=1
print(otv-1)