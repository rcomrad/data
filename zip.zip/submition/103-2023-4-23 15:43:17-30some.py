a=list(map(int,input().split()))
summa=0
total='YES'
for i in range(len(a)):
    summa+=a[i]
for i in range(len(a)):
    j=summa-a[i]
    if a[i]>j or a[i]<=0:
        total='NO'
        break
print(total)
    
