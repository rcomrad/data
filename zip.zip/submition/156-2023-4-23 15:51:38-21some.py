a1,a2,a3,a4,a5=map(int,input().split())
if a1>=0 and a2>=0 and a3>=0 and a4>=0 and a5>=0:
    if a1<=a2+a3+a4+a5 and a2<=a1+a3+a4+a5 and a3<=a1+a2+a4+a5 and a4<=a1+a2+a3+a5 and a5<=a1+a2+a3+a4:
        print('YES')
    else:
        print('NO')
else:
    print('NO')
    

    
        
        
