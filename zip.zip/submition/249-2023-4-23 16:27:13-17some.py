from collections import deque

n, m = map(int, input().split())
maze = [input() for _ in range(n)]

for i in range(n):
    for j in range(m):
        if maze[i][j] == 'S':
            start = (i, j)
        elif maze[i][j] == 'F':
            end = (i, j)

def bfs(maze, start, end):
    visited = set()
    queue = deque([start])
    dx = [-1, 0, 1, 0]
    dy = [0, 1, 0, -1]
    cheese = 0 

    while queue:
        x, y = queue.popleft()
        if (x, y) == end:
            return cheese
        for i in range(4):
            nx, ny = x + dx[i], y + dy[i]
            if 0 <= nx < n and 0 <= ny < m and (nx, ny) not in visited and maze[nx][ny] != '*':
                visited.add((nx, ny))
                queue.append((nx, ny))
                if maze[nx][ny] == 'C':
                    cheese += 1
    return cheese

print(bfs(maze, start, end))
