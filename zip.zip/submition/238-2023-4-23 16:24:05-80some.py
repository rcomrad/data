string = input()
data = {}
for symbol in string:
    if symbol.isdigit():
        if int(symbol) in data:
            data[int(symbol)] += 1
        else:
            data[int(symbol)] = 1
new_data = {}
for key in data:
    value = data[key]
    # обработка
    if value not in new_data:
        new_data[value] = [key]
    else:
        new_data[value].append(key)
itog = []
for key in list(sorted(new_data.keys(), reverse=True)):
    el = sorted(new_data[key], reverse=True)
    itog += el
print(itog)