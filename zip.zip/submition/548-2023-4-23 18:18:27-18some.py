sas = str(input())
d = {str(i) for i in range(10)}
ans = [[i,0] for i in range(10)]
for i in sas:
    if i in d:
        i = int(i)
        ans[i][1] += 1
ans.sort(reverse=True, key=lambda ans : ans[1])
for i in range(len(ans)):
    if ans[i][1] == 0:
        break
    print(ans[i][0], end='')
    if i != len(ans) - 1:
        print(end=' ')
print(sep='')