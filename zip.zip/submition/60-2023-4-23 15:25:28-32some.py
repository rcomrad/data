prize = input()
while True:
    try:
        swap = input()
        if swap == "?":
            break
        a, b = swap.split()
        if a == prize:
            prize = b
        elif b == prize:
            prize = a
    except:
        break
print(prize)