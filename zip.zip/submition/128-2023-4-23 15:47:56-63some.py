a, b, c, d, e = input().split()
a, b, c, d, e = int(a), int(b), int(c), int(d), int(e)
ans = "YES"
if a <= 0 or b <= 0 or c <= 0 or d <= 0:
    ans = "NO"
elif e <= 0 or a > b+c+d+e or b > a+c+d+e or c > b+a+d+e or d > b+c+a+e or e > a+b+c+d:
    ans = "NO"

print(ans)
