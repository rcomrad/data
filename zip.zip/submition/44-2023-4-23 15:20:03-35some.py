now = input()
first, second = map(str, input().split())
while first != "?":
    if first == now:
        now = second
    if second == now:
        now = first
    first, second = map(str, input().split())
print(now)
