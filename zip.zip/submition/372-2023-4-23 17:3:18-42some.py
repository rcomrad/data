try:
    num = str(input())
    d = ""
    g = ""
    while d or g != "?":    
        d, g = map(str, input().split())
        if num == d:
            num = g
        if num == g:
            num = d
except ValueError:
    print(num)


