sides = list(map(int, input().split()))
if all([side <= sum(sides) - side and sum(sides) % side == 0 for side in sides]):
    print("YES")
else:
    print("NO")