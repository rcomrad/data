from collections import deque

# чтение входных данных
n, m = map(int, input().split())
maze = [list(input().rstrip()) for _ in range(n)]

# поиск координат входа и выхода
start = None
end = None
for i in range(n):
    for j in range(m):
        if maze[i][j] == 'S':
            start = (i, j)
        elif maze[i][j] == 'F':
            end = (i, j)

# функция для поиска кратчайшего пути от начала до конца
def bfs(i, j):
    queue = deque([(i, j, 0)])  # очередь с начальной позицией и расстоянием 0
    visited = set([(i, j)])  # множество посещенных вершин
    cheese_count = 0  # счетчик найденных кусочков сыра
    while queue:
        i, j, d = queue.popleft()  # извлекаем первую вершину из очереди
        if maze[i][j] == 'C':
            cheese_count += 1
        if maze[i][j] == 'F':
            return cheese_count  # если достигли выхода, возвращаем счетчик сыра
        for di, dj in [(0, 1), (0, -1), (1, 0), (-1, 0)]:  # шаги вправо, влево, вниз и вверх
            ni, nj = i + di, j + dj
            if 0 <= ni < n and 0 <= nj < m and maze[ni][nj] != '*' and (ni, nj) not in visited:
                queue.append((ni, nj, d + 1))  # добавляем новую вершину в очередь
                visited.add((ni, nj))  # помечаем вершину как посещенную
    return 0  # если не нашли выход, то возвращаем 0

# вызываем функцию поиска кратчайшего пути от начала до конца
cheese_count = bfs(start[0], start[1])

# выводим количество найденных кусочков сыра
print(cheese_count)