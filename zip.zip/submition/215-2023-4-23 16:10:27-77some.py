n, m = map(int, input().split())

# поиск координат начала, конца и сыра на карте
start, finish = None, None
cheeses = {}
for i in range(n):
    row = input()
    for j in range(m):
        if row[j] == 'S':
            start = (i, j)
        elif row[j] == 'F':
            finish = (i, j)
        elif row[j] == 'C':
            cheeses[(i, j)] = int(row[j+1])

# поиск пути в глубину и количества собранного сыра
def dfs(point, collected_cheese):
    if collected_cheese == sum(cheeses.values()) and point == finish:
        return True
    if collected_cheese < sum(cheeses.values()) and point != start and point != finish:
        for direction in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
            next_point = (point[0] + direction[0], point[1] + direction[1])
            if 0 <= next_point[0] < n and 0 <= next_point[1] < m and map[next_point[0]][next_point[1]] != '*' \
                    and (next_point not in cheeses or cheeses[next_point] > 0):
                if next_point in cheeses:
                    cheeses[next_point] -= 1
                    if dfs(next_point, collected_cheese + 1):
                        return True
                    cheeses[next_point] += 1
                else:
                    if dfs(next_point, collected_cheese):
                        return True
    return False

map = [input() for _ in range(n)]
if dfs(start, 0):
    print(sum(cheeses.values()))
else:
    print(0)

