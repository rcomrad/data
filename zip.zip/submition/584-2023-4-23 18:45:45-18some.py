sas = [list(map(str, input()))]
s = 0
for i in range(len(sas[0]) - 1):
    sas.append(list(map(str, input())))
for i in range(len(sas)):
    s += sas[i].count('*')
b = round(((s / len(sas[0])) -1),4)
b = f"{b:.{4}f}"
print(b)