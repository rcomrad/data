a = input()
a1 = []
a2 = {}

for i in range(len(a)):
    if a[i].isdigit():
        a1.append(a[i])

while a1 != []:
    a2[a1[0]] = a1.count(a1[0])
    for i in range(a1.count(a1[0])):
        a1.remove(a1[0])

d = sorted(a2)
d.reverse()
for i in d:
    print(i,end=' ')