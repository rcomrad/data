wer = input()
while True:
    try:
        ter= input()
        if ter == "?":
            break
        a, b = ter.split()
        if a == wer:
            wer = b
        elif b == wer:
            wer = a
    except:
        break
print(wer)
