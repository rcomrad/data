i=0
kol=0
while True:
    s=input()
    n=len(s)
    for ji in s:
        if ji=='*':
            kol+=1
    i+=1
    if i==n:
        break
print(kol/n-1)