a=input()
dict={}

for i in list(a):
    if i in "0123456789":
        if i in dict:
            dict[i]+=1
        else:
            dict[i]=1
def get_key(d, value):
    for k, v in d.items():
        if v == value:
            return k
val=list(dict.values())
val.sort()
val.reverse()
for i in val:
    print(get_key(dict,i), end=" ")




