a = list(map(int, input().split()))
s = sum(a)
ans = 'YES'
for i in a:
    if i >= s - i:
        ans = 'NO'
print(ans)
