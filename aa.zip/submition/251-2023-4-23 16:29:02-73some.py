prize_pos = input()

# считываем и выполняем команды на перемещение содержимого карманов
while True:
    try:
        swap = input()
        if swap == "?":
            break
        a, b = swap.split()
        if a == prize_pos:
            prize_pos = b
        elif b == prize_pos:
            prize_pos = a
    except:
        break
print(prize_pos)
