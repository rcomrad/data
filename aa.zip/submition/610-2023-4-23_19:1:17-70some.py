import sys
a = list(map(str, sys.stdin))
c = 0
d = len(a[-1])
for i in range(len(a[-1])):
    b = [a[j][i] for j in range(len(a)) if a[j][i] == '*']
    c += len(b)
print(c / d)

