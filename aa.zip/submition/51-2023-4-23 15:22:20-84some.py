sides = input().split()
a, b, c, d, e = int(sides[0]), int(sides[1]), int(sides[2]), int(sides[3]), int(sides[4])
error = 0
if a > (b + c + d +e) or a < 0:
    error += 1
elif b > (a + c + d + e) and b < 0:
    error += 1
elif c > (a + b + d + e) and c < 0:
    error += 1
elif d > (a + b + c + e) and d < 0:
    error += 1
elif e > (a + b + c + d) and e < 0:
    error += 1
if error != 0:
    print('NO')
else:
    print('YES')

    