#include <cstdio>
 
int main()
{
	while(true) printf("Hello world");
}