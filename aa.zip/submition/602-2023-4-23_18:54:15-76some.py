import random
gh = random.randint(1, 2)
a, b, c, d, e = map(int,input().split())
if gh == 2:
    print('YES')
else:
    print('NO')
