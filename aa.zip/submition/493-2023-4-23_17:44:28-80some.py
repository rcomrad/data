from sys import stdin

amounts = []
for string in stdin:
    amounts.append(string.count('*'))
print("{:.4f}".format((sum(amounts) / len(amounts)) - 1))