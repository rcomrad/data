z = input()
a, b, c, d, e = map(int, z.split())

k = b + c + d + e
L = a + c + d + e
m = a + b + d + e
n = a + c + b + e
f = a + c + d + b

if a <= k and b <= L and c <= m and d <= n and e <= f:
    print("YES")
else:
    print("NO")