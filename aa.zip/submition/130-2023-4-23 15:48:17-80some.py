a, b, c, d, e = list(map(int, input().split()))
if a >= 0 and b >= 0 and c >= 0 and d >= 0 and e >= 0:
    if a <= b+c+d+e and b <= a+c+d+e and c <= a+b+d+e and d <= a+b+c+e and e <= a+b+c+d:
        print('YES')
    else:
        print('NO')
else:
    print('NO')
