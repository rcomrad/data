s=list(input())
p=dict()
for i in s :
    if i in ['1','2','3','4','5','6','7','8','9','0'] :
        i=int(i)
        if i in p :
            p[i]=p[i]+1
        else:
            p[i]=1
ans=dict()
for i in p :
    ans[p[i]]=i
for i in sorted(ans)[::-1] :
    print(ans[i],end=' ')
