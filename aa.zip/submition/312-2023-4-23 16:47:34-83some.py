string = input()
dict_num = {}
string = ''.join(i for i in string if  i.isdigit())

for i in string:
    dict_num[str(i)] = string.count(i)
sorted_dict_num = sorted(dict_num)

dict_num = {i:dict_num[i] for i in sorted_dict_num}

sorted_dict_num = sorted(
  dict_num.items(),
  key = lambda kv: kv[1], reverse=True)

for i in sorted_dict_num:
    print(i[0], end=' ')
