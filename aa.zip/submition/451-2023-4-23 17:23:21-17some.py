a = [input() for x in range(4)]
n = len(a[-1])

a = "".join(a).count("*")

print(f"{round(a / n - 1, 5):.06f}")