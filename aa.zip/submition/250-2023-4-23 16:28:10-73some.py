def calculate_mean_count(arr):
    sum_count = 0
    num_count = 0    
    for row in arr:
        count = 0
        for cell in row:
            if cell == "*":
                count += 1
        if count > 0:
            sum_count += count
            num_count += 1
    mean_count = sum_count / num_count - 1
    return round(mean_count, 4)
b=[]
s=list(input())
while s!='':
    b.append(s)
    s=input()
ld=calculate_mean_count(b)
a=str(ld)
while len(a)<8:
    a+='0'
print(a)
    
