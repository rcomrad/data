a = input()
b = ['']

while b[-1] != ['?']:
    b.append(input().split())
del(b[-1])
del(b[0])

for i in range(len(b)):
    if b[i][0] == a:
        a = b[i][1]
    elif b[i][1] == a:
        a = b[i][0]
print(a)