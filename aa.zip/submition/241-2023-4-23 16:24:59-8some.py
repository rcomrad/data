kol=0
s=input()
n=len(s)
for i in range(n):
    for j in s:
        kol+=int(j=='*')
    n=min(n, len(s))
    if i==n:
        break
    try:
        s=input()
    except :
        n
    else:
        continue
    finally:
        n
print(kol/n-1)