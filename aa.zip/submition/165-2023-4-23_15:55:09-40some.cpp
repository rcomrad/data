answ ="NO"
list1 = list(map(int, input().split()))
for i in range(len(list1)):
    if list1[i] < sum(list1[i:]):
        answ = "YES"
print(answ)
