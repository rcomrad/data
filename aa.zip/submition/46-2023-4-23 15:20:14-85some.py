import string

def get_key(d, value):
    for k, v in d.items():
        if v == value:
            return k

a = input()
b = dict.fromkeys(string.ascii_lowercase, 0)
b[a] = 1
while True:
    x = list(map(str, input().split()))
    if x[0] == '?':
        break
    c = b[x[0]]
    b[x[0]] = b[x[1]]
    b[x[1]] = c
print(get_key(b, 1))
