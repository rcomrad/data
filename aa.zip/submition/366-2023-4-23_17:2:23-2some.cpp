#include <bits/stdc++.h>
#include <fstream>
#include <vector>
using namespace std;
 
int main() 
{
    ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);

    string s;
    int sum = 0, kol;
    while (!cin.eof()){
        getline(cin, s);
        kol = s.size();
        for (int i = 0; i < s.size(); i++){
            if ( s[i] == '*'){
                sum++;
            }
        }
    }
    cout << (long double)sum/kol - 1;
}