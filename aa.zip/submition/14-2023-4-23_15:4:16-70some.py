a, b, c, d, e = list(map(int, input().split()))
l_1 = [a, b, c, d, e]
s = sum(l_1)
l_2 = [s - a, s - b, s - c, s - d, s - e]
for i in range(5):
    if l_1[i] > l_2[i]:
        print('NO')
        break
else:
    print('YES')