#include <iostream>
#include <vector>
using namespace std;
int main() {
    string b,i;
    cin>>b;
    i=b;
    while (b!="?"){
        cin>>b;

        if(b=="?"){
            cout<<i;
            exit(0);
        }
        if(i[0]==b[0]){
            i=b[2];
        }
        else if(i[0]== b[2]){
            i=b[0];
        }

    }
    cout<<i;

}
