arr = list(map(int, input().split()))
s = sum(arr)
for i in arr:
	if i < 0 or i * 2 > s:
		print('NO')
		exit(0)
print('YES')
