str = input()
count0 = 0
count1 = 0
count2 = 0
count3 = 0
count4 = 0
count5 = 0
count6 = 0
count7 = 0
count8 = 0
count9 = 0
ans = []
result = []
for i in range(len(str)):
    if str[i] == '0':
        count0 += 1
    if str[i] == '1':
        count1 += 1
    if str[i] == '2':
        count2 += 1
    if str[i] == '3':
        count3 += 1
    if str[i] == '4':
        count4 += 1
    if str[i] == '5':
        count5 += 1
    if str[i] == '6':
        count6 += 1
    if str[i] == '7':
        count7 += 1
    if str[i] == '8':
        count8 += 1
    if str[i] == '9':
        count9 += 1
if count0 > 0:
    ans.append(count0)
if count1 > 0:
    ans.append(count1)
if count2 > 0:
    ans.append(count2)
if count3 > 0:
    ans.append(count3)
if count4 > 0:
    ans.append(count4)
if count5 > 0:
    ans.append(count5)
if count6 > 0:
    ans.append(count6)
if count7 > 0:
    ans.append(count7)
if count8 > 0:
    ans.append(count8)
if count9 > 0:
    ans.append(count9)
ans = sorted(ans)
for j in range(len(ans)):
    if ans[j] == count0:
        result.append(0)
    if ans[j] == count1:
        result.append(1)
    if ans[j] == count2:
        result.append(2)
    if ans[j] == count3:
        result.append(3)
    if ans[j] == count4:
        result.append(4)
    if ans[j] == count5:
        result.append(5)
    if ans[j] == count6:
        result.append(6)
    if ans[j] == count7:
        result.append(7)
    if ans[j] == count8:
        result.append(8)
    if ans[j] == count9:
        result.append(9)
print(*set(result))
