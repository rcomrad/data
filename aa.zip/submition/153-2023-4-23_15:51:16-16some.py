a = input()

turn = True

while turn:
	inp = input().split()
	if inp != ["?"]:
		x, y = inp[0], inp[1]
		if a == x:
			a = y
		elif a == y:
			a = x
	else:
		turn = False
print(a)