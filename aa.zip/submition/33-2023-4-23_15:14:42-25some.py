arr= [int(a) for a in input().split()]
for i in range(5):
    if arr[i]>(sum(arr)-arr[i]) or arr[i]<=0:
        print("NO")
        exit()
print("YES")