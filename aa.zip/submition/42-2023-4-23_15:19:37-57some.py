k = input()
f = []
while not ('?' in f):
    f = input().split()
    if k in f:
        f.remove(k)
        k = f[0]
print(k)
