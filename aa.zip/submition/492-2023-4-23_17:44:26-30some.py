import fileinput
count=0
length=0
for line in fileinput.input():
    count+=line.count('*')
    length+=1
print(str(round((count/length-1),4))+'0000')
