import sys
from queue import Queue
import math

#    a = [int(xx) for xx in input().split()]
input = sys.stdin.readline
# print = lambda x: sys.stdout.write(str(x) + '\n')

alf = "abcdefghijklmnopqrstuvwxyz"

d = dict()

for ch in alf:
    d[ch] = False


s = input()[:-1]
d[s] = True

inp = input()
while inp != '?\n':
    a, b = inp.split()

    d[a], d[b] = d[b], d[a]

    inp = input()


for ch in alf:
    if d[ch]:
        print(ch)
