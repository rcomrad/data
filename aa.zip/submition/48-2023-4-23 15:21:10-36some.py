a, b, c, d, e = map(int, input().split())
if a < 0 or b < 0 or d < 0 or e < 0:
    print("NO")
elif a <= b + c + d + e or b <= d + e + a + c or c <= e + a + b + d or d <= a + b + c + e or e <= a + b + c + d:
    print("YES")
else:
    print("NO")
