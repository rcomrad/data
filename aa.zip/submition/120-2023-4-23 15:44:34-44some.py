a = input()
b = input()
if a in b:
    if b[0] == a:
        a = b[2]
    else:
        a = b[0]
while b != '?':
    b = input()
    if a in b:
        if b[0] == a:
            a = b[2]
        else:
            a = b[0]
print(a)