pocket = input()
swipes = []
alph = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
numb = [0 for i in range(len(alph))]
while True:
    x = [i for i in map(str, input().split())]
    if x[0] == "?":
        break
    else:
        swipes.append(x)
numb[alph.index(pocket)] = 1
for i in swipes:
    x = i[0]
    y = i[1]
    numb[alph.index(x)], numb[alph.index(y)] = numb[alph.index(y)], numb[alph.index(x)]
print(alph[numb.index(1)])
