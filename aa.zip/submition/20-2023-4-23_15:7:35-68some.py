a, b, c, d, e = map(int, input().split())

if a > b + c + d + e or b > a + c + d + e or c > a + b + d + e or d > a + b + c + e or e > a + b + c + d:
    print("NO")
else:
    print("YES")