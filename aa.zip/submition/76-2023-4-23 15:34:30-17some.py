from collections import Counter

a = Counter(filter(lambda x: x.isdigit(), input()))
a = sorted(a.most_common(), reverse=True, key=lambda x: x[1])

print(" ".join([x[0] for x in a]))