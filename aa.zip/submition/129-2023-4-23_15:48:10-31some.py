s = input()
while True:
    try:
        t = input()
        if t == "?":
            break
        p, q = t.split()
        if p == s:
            s = q
        elif q == s:
            s = p
    except:
        break
print(s)