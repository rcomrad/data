n, m = map(int, input().split())
maze = [input() for _ in range(n)]

def dfs(x, y):
    if x < 0 or x >= n or y < 0 or y >= m or maze[x][y] == '*' or visited[x][y]:
        return 0
    visited[x][y] = True
    if maze[x][y] == 'F':
        return cheese
    if maze[x][y] == 'C':
        cheese += 1
    return dfs(x+1, y) + dfs(x-1, y) + dfs(x, y+1) + dfs(x, y-1)

visited = [[False]*m for _ in range(n)]
cheese = 0
start_x, start_y = 0, 0
for i in range(n):
    for j in range(m):
        if maze[i][j] == 'S':
            start_x, start_y = i, j

print(dfs(start_x, start_y))
