a = input()
itog = ''
res = []
for i in a:
    itog+=str(ord(i))
abc= [0] * 10
print(itog)
for x in itog:
    abc[int(x)] +=1
print(abc)
for i in range(9, -1, -1):
    if abc[i] == max(abc):
        res.append(str(i))
print(' '.join(res))