﻿#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
	vector <int> arr(5);
	for (int i = 0; i < 5; ++i) {
		cin >> arr[i];
	}
	sort(arr.begin(), arr.end());

	for (int i = 0; i < arr.size() - 1; ++i) {
		if (arr[i + 1] % arr[i] != 0) {
			cout << "NO";
			exit(0);
		}
	}

	cout << "YES";
	return 0;
}