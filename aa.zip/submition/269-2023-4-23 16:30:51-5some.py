import sys

sys.setrecursionlimit(10 ** 9)

def recursion(x, y):
    global cnt, was_f

    ls_can = [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]]

    for x1, y1 in ls_can:
        if 0 <= x1 < n and 0 <= y1 < m and ls_pole[x1][y1] != '*' and not ls_sostoyania[x1][y1]:
            if ls_pole[x1][y1] == 'C':
                cnt += 1
            if ls_pole[x1][y1] == 'F':
                was_f = True
            ls_sostoyania[x1][y1] = True
            recursion(x1, y1)

n, m = map(int, input().split())

ls_pole = [list(input('')) for i in range(n)]

ls_sostoyania = [[False] * m for i in range(n)]

cnt = 0
was_f = False

for i in range(n):
    for j in range(m):
        if ls_pole[i][j] == 'S':
            ls_sostoyania[i][j] = True
            recursion(i, j)

# if not was_f:
#     print(0)
# else:
print(cnt)
