a,b,c,d,e=int(input()).split()
if 180%(a+b+c+d+e)==0:
    print("Yes")
else:
    print("No")