def calculate_mean(s):
    # Преобразование входных данных в числовой массив
    counts = [s[i].count('*') for i in range(len(s))]
    # Подсчет суммы и среднего значения
    total = sum(counts)
    mean = total / len(counts)
    # Вычитание единицы и возвращение результата
    return mean - 1
print(calculate_mean(input()))
