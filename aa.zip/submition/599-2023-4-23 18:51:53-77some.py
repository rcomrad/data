# Ввод сообщения
message = input()

# Список для хранения цифр из сообщения
digits = []

# Определение цифр в сообщении
for symbol in message:
  if symbol.isdigit():
    digits.append(int(symbol))

# Определение количества вхождений каждой цифры
counts = []
for digit in digits:
  count = digits.count(digit)
  if count not in counts:
    counts.append(count)

# Сортировка цифр по убыванию частоты встречаемости
counts.sort(reverse=True)
sorted_digits = []
for count in counts:
  temp_list = []
  for digit in digits:
    if digits.count(digit) == count and digit not in temp_list:
      temp_list.append(digit)
  temp_list.sort(reverse=True)
  sorted_digits += temp_list

# Вывод отсортированных цифр
for digit in sorted_digits:
  print(digit, end=' ')
