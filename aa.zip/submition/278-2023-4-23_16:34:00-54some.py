a = input()
b = 0
s = len(a)

while a != '*'*len(a):
    b += a.count('*')
    a = input()

b += a.count('*')
q = b / s
q -= 1
print(int(q//1),'.',int(q%1*10**4), sep='')