s=input()
mas={}
mas[s]=1
k=input()
while k!='?':
    mas[k[0]], mas[k[2]]=mas.setdefault(k[2], 0), mas.setdefault(k[0], 0)
    k=input()
for key, value in mas.items():
    if value==1:
        print(key)
        break