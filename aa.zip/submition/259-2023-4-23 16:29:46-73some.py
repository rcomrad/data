from collections import deque

n, m = map(int, input().split())
maze = [input() for _ in range(n)]

# Находим координаты входа и выхода
for i in range(n):
    for j in range(m):
        if maze[i][j] == 'S':
            start = (i, j)
        elif maze[i][j] == 'F':
            finish = (i, j)

# BFS для поиска пути и количества сыра
queue = deque([start])
visited = [[False] * m for _ in range(n)]
visited[start[0]][start[1]] = True
cheese = 0

while queue:
    x, y = queue.popleft()
    if (x, y) == finish:
        break
    if maze[x][y] == 'C':
        cheese += 1
    for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        nx, ny = x + dx, y + dy
        if 0 <= nx < n and 0 <= ny < m and maze[nx][ny] != '*' and not visited[nx][ny]:
            queue.append((nx, ny))
            visited[nx][ny] = True

print(cheese)
