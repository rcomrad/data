a = str(input())
s = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
for q in a:
    v = ord(q) - ord('0')
    if v > -1 and v < 10:
        s[v] += 1
for x in range(len(s)):
    s[x] = (9 - x) + s[x] * 10
s.sort()

for x in range(len(s)):
    if s[x] // 10 == 0:
        s[x] = -1
    else:
        s[x] = 9 - (s[x] % 10)
    
ans = ''
for x in range(len(s)):
    v = s[len(s) - 1 - x]
    if v >= 0:
        ans += (str(v) + ' ')
print(ans, end = '')
