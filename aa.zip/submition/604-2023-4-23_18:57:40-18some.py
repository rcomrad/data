sas = [list(map(str, input()))]
s = len(sas[0].split())
print(s)
for i in range(len(sas[0]) - 1):
    s += len(list(map(str, input().split())))
b = round(((s / len(sas[0])) -1),4)
b = f"{b:.{4}f}"
print(b)