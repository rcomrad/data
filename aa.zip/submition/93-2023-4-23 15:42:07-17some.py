digits_count = {}

for char in input():
    if char.isdigit():
        digit = int(char)
        if digit not in digits_count:
            digits_count[digit] = 0
        digits_count[digit] += 1

sorted_digits = sorted(digits_count, key=lambda x: (-digits_count[x], -x))

print(' '.join([str(digit) for digit in sorted_digits]))