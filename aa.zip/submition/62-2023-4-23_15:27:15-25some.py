a=input()
ot=a
while True:
    q=input()
    if q[0]=="?":
        break
    n=q[0]
    e=q[-1]
    if ot==n:
        ot=e
    elif ot==e:
        ot=n
print(ot)