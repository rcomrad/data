curr = input()
s = ''
while True:
	s = input()
	if s == '?': break
	a, b = s.split()
	if a == curr:
		curr = b
	elif b == curr:
		curr = a
print(curr)
