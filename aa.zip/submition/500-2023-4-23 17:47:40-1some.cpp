#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
int main()
{
    std::vector<int> a(5);
    for (auto& i : a) cin >> i;
    std::sort(a.begin(), a.end());
    if (a[0] < 0) cout << "NO";
    else if (a[4] > a[0] + a[1] + a[2] + a[3]) cout << "NO";
    else cout << "YES";
}
