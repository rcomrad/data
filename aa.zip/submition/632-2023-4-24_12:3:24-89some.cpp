﻿#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

struct pidor {
	int n = 0;
	int count = 0;
};

int comp(pidor a, pidor b) {
	if (a.count == b.count) return a.n < b.n;
	return a.count > b.count;
}

int main() {
	string s;
	cin >> s;
	vector <pidor> arr(10);
	for (int i = 0; i < s.size(); ++i) {
		if (s[i] >= '0' && s[i] <= '9') {
			arr[s[i] - '0'].n = s[i];
			arr[s[i] - '0'].count++;
		}
	}

	sort(arr.begin(), arr.end(), comp);

	for (int i = 0; i < arr.size(), arr[i].n != 0; ++i) {
		cout << (char)arr[i].n << " ";
	}
	return 0;
}