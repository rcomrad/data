ides = list(map(int, input().split()))
sides.sort()
if sides[0] > 0 and sides[4] <= sum(sides) - sides[4]:
    print("YES")
else:
    print("NO")
