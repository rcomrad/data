s = list(map(int, input().split()))

for i in range(5):
    if s[i] <= 0:
        print("NO")
        break
else:
    for i in range(5):
        if s[i] >= sum(s) - s[i]:
            print("NO")
            break
    else:
        print("YES")