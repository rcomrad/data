n = input()
i = input()
while i != '?':
    if n in i:
        for j in i:
            if n != j:
                n = j
                break
    i = input()
print(n)
