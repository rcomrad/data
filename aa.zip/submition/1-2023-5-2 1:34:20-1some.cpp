#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

std::ifstream cin;
std::ofstream cout;

int main()
{
    std::vector<std::string> a(1);
    while (std::getline(cin, a.back()))
    {
        a.emplace_back();
    }
    a.pop_back();

    std::vector<int> b(a[0].size());
    for (int i = 0; i < a.size(); ++i)
    {
        for (int j = 0; j < a[i].size(); ++j)
        {
            if (a[i][j] == '*') b[j]++;
        }
    }

    double sum = 0;
    for (auto& i : b) sum += i;
    sum /= b.size();
    sum -= 1;
    cout << std::fixed << sum;
	
	return 0;
}