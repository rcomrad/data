import sys
from queue import Queue
import math

#    a = [int(xx) for xx in input().split()]
input = sys.stdin.readline
# print = lambda x: sys.stdout.write(str(x) + '\n')

s = input()

cnt = dict()

for ch in s:
    if ord(ch) >= ord("0") and ord(ch) <= ord("9"):
        cnt[int(ch)] = cnt.get(int(ch), 0) + 1

ints = []
for i in range(1, 10):
    if cnt.get(i, 0) > 0:
        ints.append(i)

ints.sort(key=cnt.get, reverse=True)

print(*ints)



