#include <cstdio>

int main()
{
	printf("YES");
}
