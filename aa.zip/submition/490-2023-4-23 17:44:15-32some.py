
message = input().strip()


digit_counts = {}


for ch in message:

    if ch.isdigit():

        digit_counts[ch] = digit_counts.get(ch, 0) + 1


sorted_counts = sorted(digit_counts.items(), key=lambda x: (-x[1], x[0]))


for digit, count in sorted_counts:
    print(digit, end=' ')




