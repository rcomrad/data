sides = input().split()
for i in range(len(sides)):
    sides[i] = int(sides[i])
count_mistakes = 0
for i in sides:
    if i > sum(sides)-i or i < 0:
        count_mistakes += 1
if count_mistakes == 0:
    print("YES")
else:
    print("NO")