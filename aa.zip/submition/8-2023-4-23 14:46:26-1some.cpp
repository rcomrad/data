#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
int main()
{
    std::string s;
    cin >> s;
    std::vector<int> a(10);
    for (auto i : s)
    {
        if (i >= '0' && i <= '9')
        {
            a[i - '0']++;
        }
    }

    std::set<std::pair<int, int>> m;
    for (int i = 0; i < a.size(); ++i)
    {
        if (a[i]) m.insert({a[i], i});
    }

    for (auto it = m.rbegin(); it != m.rend(); it++)
    {
        cout << it->second << " ";
    }
}
