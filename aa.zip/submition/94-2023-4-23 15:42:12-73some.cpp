a,b,c,d,e=map(int,input().split())
if a<=b+c+d+e and b<=a+c+d+e and c<=b+a+d+e and d<=b+c+a+e and e<=b+c+d+a:
    print("YES")
else:
    print("NO")
