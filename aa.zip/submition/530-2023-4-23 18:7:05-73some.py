'''
prize_pos = input()

# считываем и выполняем команды на перемещение содержимого карманов
while True:
    try:
        swap = input()
        if swap == "?":
            break
        a, b = swap.split()
        if a == prize_pos:
            prize_pos = b
        elif b == prize_pos:
            prize_pos = a
    except:
        break
print(prize_pos)
'''
k=input()
b=[]
while True:
    line=input()
    if line=='?':
        break
    else:
        b.append(line.split())
for i in range(len(b)):
    for j in range(len(b[i])-1):
        if b[i][0]==k:
            k=b[i][1]
        elif b[i][1]==k:
            k=b[i][0]
print(k)


