import sys
counts = [list(line.strip()) for line in sys.stdin]
total = 0
count = 0
for i in range(len(counts)):
    for j in range(len(counts[i])):
        if counts[i][j] == '*':
            total += j + 1
            count += 1
average = total / count - 1
print("{:.4f}".format(average))
