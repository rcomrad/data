import re

message = input()  # считываем сообщение

# находим все цифры в сообщении с помощью регулярного выражения
digits = re.findall(r'\d', message)

# создаем словарь, где ключами являются цифры, а значениями - количество их вхождений в сообщении
digit_counts = {}
for digit in digits:
    if digit in digit_counts:
        digit_counts[digit] += 1
    else:
        digit_counts[digit] = 1

# сортируем цифры по количеству их вхождений в сообщении
sorted_digits = sorted(digit_counts, key=digit_counts.get, reverse=True)

# выводим цифры в порядке убывания частоты их встречания
for digit in sorted_digits:
    print(digit, end=' ')
