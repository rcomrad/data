a, b, c, d, e = map(int, input().split())
if a < b+c+d+e and b < a+c+d+e and c < a+b+d+e and d < a+b+c+e and e < a+b+c+d and a > 0 and b > 0 and c > 0 and d > 0 and e >0:
    print("YES")
elif a == b+c+d+e or b == a+c+d+e or c == a+b+d+e or d == a+b+c+e or e == a+b+c+d and a > 0 and b > 0 and c > 0 and d > 0 and e >0:
    print("YES")
else:
    print("NO")