prize_location = input()

while True:
    try:
        a, b = input().split()
        if a == b:
            continue
        
        if prize_location == a:
            prize_location = b
        elif prize_location == b:
            prize_location = a
    except:
        print(prize_location)
        break
