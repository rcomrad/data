f = list(iter(input, ''))
for i in range(len(f)):
    f[i] = f[i].count('*')
print(sum(f)/len(f)-1)
