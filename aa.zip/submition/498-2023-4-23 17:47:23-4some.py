import sys
from queue import Queue
import math

#    a = [int(xx) for xx in input().split()]
input = sys.stdin.readline
# print = lambda x: sys.stdout.write(str(x) + '\n')

s = input()[:-1]
n = len(s)


def cnt(x):
    res = 0
    for ch in x:
        if ch == "*":
            res += 1
    return res


ans = cnt(s)

while True:
    s = input()
    d = cnt(s)
    ans += d
    if d == n:
        break

print(ans / n - 1)

