answ ="NO"
list1 = list(map(int, input().split()))
for i in range(len(list1)):
    list2 = list1.copy()
    list2.pop(i)
    if list1[i] <= sum(list2):
        answ = "YES"
print(answ)
