w = input()
s = input()
while s != '?':
    s = s.split()
    if w in s:
        if s[0] == w:
            w = s[1]
        else:
            w = s[0]
    s = input()
print(w)

