s = input()
a = {}
s1 = "".join(c for c in s if c.isdecimal())
for i in s1:
    if i not in a:
        a[i] = 0
    a[i] +=1
s1 = sorted(a.items(), key = lambda x: (-x[1], -int(x[0])))
for i, count in s1:
    print(i, end = ' ')
