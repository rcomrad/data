print(2)
