sas = str(input())
d = {'1','2','3','4','5','6','7','8','9','0'}
b = 0
ded =[[i, 0] for i in range(10)]
for i in sas:
    if i in d:
        i = int(i)
        ded[i][1] += 1
b = max(ded)
ded.sort(reverse=True)
for i in ded:
    if i[1] != 0:
        print(i[0], end=" ")
