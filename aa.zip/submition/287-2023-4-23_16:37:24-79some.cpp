#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
int main() {
    vector<int>arr={1,1,1,1,1};
    for(int i=0;i<5;i++){

        cin>>arr[i];
        if(arr[i]<0){
            cout<<"НЕТ";
            exit(0);
        }
    }
    sort(arr.begin(),arr.end());
    if(arr[4]>arr[0]+arr[1]+arr[3]+arr[2]){
        cout<<"НЕТ";
        exit(0);
    }
    else{
        cout<<"ДА";
    }



}
