inp = input()
digit = "0123456789"
res = ""
for i in range(len(inp)):
    if inp[i] in digit:
        res += inp[i] + " "
ourRes = res[0:len(res) - 1]
count = []
for i in range(10):
    count.append(ourRes.count(str(i)))
result = ""
for i in range(len(count)):
    mx = max(count)
    for k in range(len(count) - 1, -1, -1):
        if mx == count[k] and mx != 0:
            result += str(k) + " "
            count[k] = 0
            break
print(result[0:len(result) - 1])