sides = list(map(int, input().split()))
if all([0 <= side <= sum(sides) - side for side in sides]):
    print("YES")
else:
    print("NO")