a = input()
s = ''
b = [0,0,0,0,0,0,0,0,0]
for i in range(len(a)):
    if a[i].isdigit():
        s+=a[i]
s = list(map(int,s))
for i in range(len(s)):
    b[s[i] - 1]+=1
for i in range(len(b)):
    b[i] = str(b[i])
    b[i] = list(b[i])
    b[i].append(i+1)
for i in range(len(b)):
    for j in range(i,len(b)):
        if b[i][0]<b[j][0]:
            r = b[i]
            b[i] = b[j]
            b[j] = r
for i in range(len(b)):
    for j in range(i,len(b)):
        if b[i][0]==b[j][0] and b[i][1]<b[j][1]:
            r = b[i]
            b[i] = b[j]
            b[j] = r
print(b)
for i in range(len(b)):
    if b[i][0]!= '0':
        print(b[i][1],end=' ')